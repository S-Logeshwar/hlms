/* ===== Shared UI utilities (no backend — all data is local/dummy) ===== */

// Sidebar toggle (mobile)
function initSidebarToggle(){
  const toggle = document.querySelector('.menu-toggle');
  const sidebar = document.querySelector('.sidebar');
  if(!toggle || !sidebar) return;
  toggle.addEventListener('click', ()=> sidebar.classList.toggle('open'));
  document.addEventListener('click', (e)=>{
    if(window.innerWidth<=900 && sidebar.classList.contains('open')
      && !sidebar.contains(e.target) && !toggle.contains(e.target)){
      sidebar.classList.remove('open');
    }
  });
}

// Tabs: any [data-tabs] container with .tab-btn[data-tab] + .tab-panel[data-panel]
function initTabs(){
  document.querySelectorAll('[data-tabs]').forEach(group=>{
    const btns = group.querySelectorAll('.tab-btn');
    btns.forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const target = btn.getAttribute('data-tab');
        group.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        const panelContainer = group.getAttribute('data-panels') || group.getAttribute('data-tabs');
        document.querySelectorAll(`.tab-panel[data-group="${panelContainer}"]`).forEach(p=>{
          p.classList.toggle('active', p.getAttribute('data-panel')===target);
        });
      });
    });
  });
}

// Toast notifications
function toast(message, opts={}){
  let wrap = document.querySelector('.toast-wrap');
  if(!wrap){
    wrap = document.createElement('div');
    wrap.className='toast-wrap';
    document.body.appendChild(wrap);
  }
  const el = document.createElement('div');
  el.className='toast';
  el.textContent = message;
  wrap.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transition='opacity .3s'; setTimeout(()=>el.remove(),300); }, opts.duration||2600);
}

// Modal open/close via [data-modal-open]/[data-modal-close] + target id
function initModals(){
  document.querySelectorAll('[data-modal-open]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-modal-open');
      document.getElementById(id)?.classList.add('open');
    });
  });
  document.querySelectorAll('[data-modal-close]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      btn.closest('.modal-overlay')?.classList.remove('open');
    });
  });
  document.querySelectorAll('.modal-overlay').forEach(ov=>{
    ov.addEventListener('click', (e)=>{ if(e.target===ov) ov.classList.remove('open'); });
  });
}

// Simple local "storage" helper (per-app namespace, no backend)
const LocalStore = {
  get(key, fallback){
    try{
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    }catch(e){ return fallback; }
  },
  set(key, value){
    try{ localStorage.setItem(key, JSON.stringify(value)); }catch(e){}
  }
};

function formatINR(num){
  return '₹' + Number(num).toLocaleString('en-IN');
}

document.addEventListener('DOMContentLoaded', ()=>{
  initSidebarToggle();
  initTabs();
  initModals();
});

/* ===== Loan Officer logic ===== */
function initViews(){
  const links = document.querySelectorAll('.nav a[data-view]');
  const views = document.querySelectorAll('.view[data-view]');
  const titleEl = document.getElementById('pageTitle');
  const subEl = document.getElementById('pageSub');
  const titles = {
    dashboard: ['Dashboard','Your portfolio at a glance'],
    queue: ['Application Queue','Applications assigned to you, sorted by stage'],
    mortgage: ['Mortgage & Valuation','Assess collateral for high-value loan requests'],
    repayments: ['Repayment Monitoring','Track EMI performance across your portfolio'],
    default: ['Default Management','Overdue accounts and notice generation'],
    auctions: ['Auction Management','Recovery through mortgaged asset auctions'],
    reports: ['Reports','Operational efficiency across the loan workflow']
  };
  function activate(view){
    views.forEach(v=>v.classList.toggle('active', v.getAttribute('data-view')===view));
    links.forEach(l=>l.classList.toggle('active', l.getAttribute('data-view')===view));
    if(titles[view]){ titleEl.textContent=titles[view][0]; subEl.textContent=titles[view][1]; }
    document.querySelector('.sidebar')?.classList.remove('open');
    window.scrollTo({top:0,behavior:'smooth'});
  }
  links.forEach(l=>l.addEventListener('click', e=>{e.preventDefault(); activate(l.getAttribute('data-view'));}));
  document.querySelectorAll('[data-goto]').forEach(b=>b.addEventListener('click', ()=>activate(b.getAttribute('data-goto'))));
}

function initMortgageCalc(){
  const btn = document.getElementById('calcMortgage');
  if(!btn) return;
  btn.addEventListener('click', ()=>{
    const req = Number(document.getElementById('mReq').value)||0;
    const limit = Number(document.getElementById('mLimit').value)||0;
    const property = Number(document.getElementById('mProperty').value)||0;
    const excess = Math.max(0, req-limit);
    const mortgageRequired = Math.round(excess*1.25); // banking margin guideline
    const sufficient = property >= mortgageRequired;
    const ratio = property>0 ? (req/property*100).toFixed(1) : '0';
    document.getElementById('mortgageResult').innerHTML = `
      <div class="card-flat">
        <div class="grid grid-2">
          <div><div class="stat-label">Mortgage Required</div><div class="stat-value" style="font-size:20px;">${formatINR(mortgageRequired)}</div></div>
          <div><div class="stat-label">Loan-to-Mortgage Ratio</div><div class="stat-value" style="font-size:20px;">${ratio}%</div></div>
        </div>
        <div class="mt-16"><span class="badge ${sufficient?'badge-green':'badge-coral'}">${sufficient? 'Collateral sufficient' : 'Collateral insufficient — request additional security'}</span></div>
      </div>`;
    toast('Mortgage requirement calculated');
  });
  document.getElementById('saveEval')?.addEventListener('click', ()=> toast('Evaluation record saved'));
}

function initReports(){
  const bars = document.getElementById('bars');
  if(!bars) return;
  const data = [
    ['Docs Verification', 1.2, 2],
    ['Credit Review', 2.8, 2.5],
    ['Mortgage Check', 3.6, 3],
    ['Final Approval', 1.5, 1.5],
  ];
  bars.innerHTML = data.map(([label,val,target])=>{
    const pct = Math.min(100, (val/5)*100);
    const over = val>target;
    return `<div class="mt-16">
      <div class="flex-between"><span class="text-sm" style="font-weight:600;color:var(--ink);">${label}</span><span class="text-sm mono">${val} days avg · target ${target}d</span></div>
      <div class="progress mt-8"><div class="progress-fill" style="width:${pct}%;background:${over?'linear-gradient(90deg,#BC4C3C,#d97462)':'linear-gradient(90deg,var(--teal-600),var(--teal-500))'}"></div></div>
    </div>`;
  }).join('');
}

document.addEventListener('DOMContentLoaded', ()=>{
  initViews();
  initMortgageCalc();
  initReports();
  document.getElementById('submitDecision')?.addEventListener('click', ()=>{
    const d = document.getElementById('decisionSelect').value;
    document.getElementById('reviewModal').classList.remove('open');
    toast(`Decision recorded: ${d}`);
  });
  document.getElementById('submitNotice')?.addEventListener('click', ()=>{
    document.getElementById('noticeModal').classList.remove('open');
    toast('Default notice generated and sent');
  });
  document.getElementById('submitAuction')?.addEventListener('click', ()=>{
    document.getElementById('auctionModal').classList.remove('open');
    toast('Eligibility verified — auction scheduled');
  });
});
