/* ===== Shared UI utilities (no backend — all data is local/dummy) ===== */

// Sidebar toggle (mobile)
function initSidebarToggle(){
  const toggle = document.querySelector('.menu-toggle');
  const sidebar = document.querySelector('.sidebar');
  if(!toggle || !sidebar) return;
  toggle.addEventListener('click', ()=> sidebar.classList.toggle('open'));
  document.addEventListener('click', (e)=>{
    if(window.innerWidth<=900 && sidebar.classList.contains('open')
      && !sidebar.contains(e.target) && !toggle.contains(e.target)){
      sidebar.classList.remove('open');
    }
  });
}

// Tabs: any [data-tabs] container with .tab-btn[data-tab] + .tab-panel[data-panel]
function initTabs(){
  document.querySelectorAll('[data-tabs]').forEach(group=>{
    const btns = group.querySelectorAll('.tab-btn');
    btns.forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const target = btn.getAttribute('data-tab');
        group.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        const panelContainer = group.getAttribute('data-panels') || group.getAttribute('data-tabs');
        document.querySelectorAll(`.tab-panel[data-group="${panelContainer}"]`).forEach(p=>{
          p.classList.toggle('active', p.getAttribute('data-panel')===target);
        });
      });
    });
  });
}

// Toast notifications
function toast(message, opts={}){
  let wrap = document.querySelector('.toast-wrap');
  if(!wrap){
    wrap = document.createElement('div');
    wrap.className='toast-wrap';
    document.body.appendChild(wrap);
  }
  const el = document.createElement('div');
  el.className='toast';
  el.textContent = message;
  wrap.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transition='opacity .3s'; setTimeout(()=>el.remove(),300); }, opts.duration||2600);
}

// Modal open/close via [data-modal-open]/[data-modal-close] + target id
function initModals(){
  document.querySelectorAll('[data-modal-open]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-modal-open');
      document.getElementById(id)?.classList.add('open');
    });
  });
  document.querySelectorAll('[data-modal-close]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      btn.closest('.modal-overlay')?.classList.remove('open');
    });
  });
  document.querySelectorAll('.modal-overlay').forEach(ov=>{
    ov.addEventListener('click', (e)=>{ if(e.target===ov) ov.classList.remove('open'); });
  });
}

// Simple local "storage" helper (per-app namespace, no backend)
const LocalStore = {
  get(key, fallback){
    try{
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    }catch(e){ return fallback; }
  },
  set(key, value){
    try{ localStorage.setItem(key, JSON.stringify(value)); }catch(e){}
  }
};

function formatINR(num){
  return '₹' + Number(num).toLocaleString('en-IN');
}

document.addEventListener('DOMContentLoaded', ()=>{
  initSidebarToggle();
  initTabs();
  initModals();
});

/* ===== Customer portal logic ===== */

// View switching (sidebar-driven)
function initViews(){
  const links = document.querySelectorAll('.nav a[data-view]');
  const views = document.querySelectorAll('.view[data-view]');
  const titleEl = document.getElementById('pageTitle');
  const subEl = document.getElementById('pageSub');
  const titles = {
    dashboard: ['Dashboard', "Welcome back — here's where your loan stands"],
    applications: ['My Applications', 'Track every application you have submitted'],
    apply: ['Apply for Loan', 'Fill in your details to start a new application'],
    eligibility: ['Eligibility Check', 'Estimate what you qualify for before you apply'],
    repayments: ['Repayments', 'Your EMI schedule and outstanding balance'],
    documents: ['Documents', 'Upload and track your loan documents'],
    services: ['Post-Disbursement Services', 'Requests for loans already disbursed'],
    profile: ['Profile', 'Keep your personal and financial details up to date']
  };
  function activate(view){
    views.forEach(v=>v.classList.toggle('active', v.getAttribute('data-view')===view));
    links.forEach(l=>l.classList.toggle('active', l.getAttribute('data-view')===view));
    if(titles[view]){ titleEl.textContent = titles[view][0]; subEl.textContent = titles[view][1]; }
    document.querySelector('.sidebar')?.classList.remove('open');
    window.scrollTo({top:0, behavior:'smooth'});
  }
  links.forEach(l=> l.addEventListener('click', (e)=>{ e.preventDefault(); activate(l.getAttribute('data-view')); }));
  document.querySelectorAll('[data-goto]').forEach(btn=>{
    btn.addEventListener('click', ()=> activate(btn.getAttribute('data-goto')));
  });
}

// Eligibility calculator
function initEligibility(){
  const btn = document.getElementById('calcEligibility');
  if(!btn) return;
  btn.addEventListener('click', ()=>{
    const income = Number(document.getElementById('elIncome').value)||0;
    const existing = Number(document.getElementById('elExisting').value)||0;
    const amount = Number(document.getElementById('elAmount').value)||0;
    const tenure = Number(document.getElementById('elTenure').value)||1;
    const cibil = Number(document.getElementById('elCibil').value)||0;

    const rate = 0.085; // indicative annual rate
    const r = rate/12;
    const n = tenure*12;
    const emi = amount>0 ? (amount*r*Math.pow(1+r,n))/(Math.pow(1+r,n)-1) : 0;
    const dti = income>0 ? ((existing+emi)/income*100) : 100;
    const maxEmi = income*0.5 - existing;
    const maxLoan = maxEmi>0 ? (maxEmi*(Math.pow(1+r,n)-1))/(r*Math.pow(1+r,n)) : 0;

    let status, badgeClass, reasons=[], tips=[];
    if(cibil>=730 && dti<=45){
      status='Eligible'; badgeClass='badge-green';
      reasons.push('Your CIBIL score and debt-to-income ratio meet our standard lending criteria.');
    } else if(cibil>=650 && dti<=55){
      status='Conditionally Eligible'; badgeClass='badge-amber';
      reasons.push('Your profile qualifies with conditions — a mortgage or co-applicant may be required.');
      if(dti>45) tips.push('Reduce existing EMIs or choose a longer tenure to lower your DTI ratio.');
      if(cibil<730) tips.push('Improving your CIBIL score above 730 could unlock better terms.');
    } else {
      status='Not Eligible'; badgeClass='badge-coral';
      reasons.push('Your current DTI ratio or CIBIL score is below our minimum threshold for this amount.');
      tips.push('Consider a lower loan amount or longer tenure to bring EMI within 50% of income.');
      tips.push('Clearing existing short-term loans can improve your eligibility.');
    }

    document.getElementById('eligResult').innerHTML = `
      <div class="badge ${badgeClass}" style="font-size:13px;padding:6px 14px;">${status}</div>
      <div class="grid grid-2 mt-16">
        <div class="card-flat"><div class="stat-label">Estimated EMI</div><div class="stat-value" style="font-size:20px;">${formatINR(Math.round(emi))}</div></div>
        <div class="card-flat"><div class="stat-label">DTI Ratio</div><div class="stat-value" style="font-size:20px;">${dti.toFixed(1)}%</div></div>
      </div>
      <div class="card-flat mt-16"><div class="stat-label">Maximum eligible loan (est.)</div><div class="stat-value" style="font-size:20px;">${formatINR(Math.round(maxLoan))}</div></div>
      <div class="mt-16"><strong style="font-size:13px;color:var(--teal-900);">Why this result</strong><p class="text-sm mt-8">${reasons.join(' ')}</p></div>
      ${tips.length? `<div class="mt-16"><strong style="font-size:13px;color:var(--teal-900);">Ways to improve</strong><ul class="text-sm mt-8" style="padding-left:18px;line-height:1.8;">${tips.map(t=>`<li>${t}</li>`).join('')}</ul></div>` : ''}
    `;
    toast('Eligibility calculated');
  });
}

// Draft saving for loan application
function initApplyForm(){
  const form = document.getElementById('applyForm');
  const saveBtn = document.getElementById('saveDraftBtn');
  const draftList = document.getElementById('draftList');
  if(!form) return;

  function renderDrafts(){
    const drafts = LocalStore.get('hk_drafts', []);
    if(!draftList) return;
    draftList.innerHTML = drafts.length ? drafts.map((d,i)=>`
      <div class="card-flat">
        <div class="flex-between"><strong style="color:var(--teal-900);font-size:13.5px;">Draft — ${d.purpose||'Loan application'}</strong><span class="text-sm text-slate mono">${d.date}</span></div>
        <p class="text-sm mt-8">Amount: ${formatINR(d.amount||0)} · Tenure: ${d.tenure||'-'} yrs</p>
        <div class="flex-gap mt-8"><button class="btn btn-secondary btn-sm" data-resume="${i}">Resume</button><button class="btn btn-danger btn-sm" data-discard="${i}">Discard</button></div>
      </div>`).join('') : `<div class="empty" style="grid-column:1/-1;">No saved drafts</div>`;

    draftList.querySelectorAll('[data-discard]').forEach(b=>b.addEventListener('click', ()=>{
      const drafts = LocalStore.get('hk_drafts', []);
      drafts.splice(Number(b.getAttribute('data-discard')),1);
      LocalStore.set('hk_drafts', drafts);
      renderDrafts();
      toast('Draft discarded');
    }));
  }

  saveBtn.addEventListener('click', ()=>{
    const drafts = LocalStore.get('hk_drafts', []);
    drafts.push({
      date: new Date().toLocaleDateString('en-IN'),
      amount: Number(document.getElementById('applyAmount').value)||0,
      tenure: document.getElementById('applyTenure').value,
      purpose: form.querySelector('select').value
    });
    LocalStore.set('hk_drafts', drafts);
    renderDrafts();
    toast('Draft saved');
  });

  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const trackingNo = 'HK-LN-' + Math.floor(10000+Math.random()*89999);
    toast(`Application submitted — tracking number ${trackingNo}`, {duration:4000});
    form.reset();
  });

  renderDrafts();
}

// EMI schedule table (generated)
function initEmiTable(){
  const tbody = document.getElementById('emiTable');
  if(!tbody) return;
  const rows = [];
  const start = new Date(2026,6,5);
  for(let i=1;i<=6;i++){
    const d = new Date(start); d.setMonth(start.getMonth()+i-1);
    const status = i===1 ? 'badge-amber' : 'badge-slate';
    const statusText = i===1 ? 'Due soon' : 'Upcoming';
    rows.push(`<tr><td class="mono">#${i}</td><td class="mono">${d.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</td><td class="mono">₹18,460</td><td><span class="badge ${status}">${statusText}</span></td><td><button class="btn btn-primary btn-sm pay-btn">Pay now</button></td></tr>`);
  }
  tbody.innerHTML = rows.join('');
  tbody.querySelectorAll('.pay-btn').forEach(b=> b.addEventListener('click', ()=> toast('Payment simulated — receipt sent to your email')));
}

// Document upload (simulated, no backend)
function initDocUpload(){
  const input = document.getElementById('fileInput');
  const browse = document.getElementById('browseLink');
  const box = document.querySelector('.upload-box');
  const table = document.getElementById('docTable');
  if(!input) return;
  browse.addEventListener('click', (e)=>{ e.preventDefault(); input.click(); });
  ['dragover','drop'].forEach(evt=> box.addEventListener(evt, e=>e.preventDefault()));
  box.addEventListener('drop', e=>{
    if(e.dataTransfer.files.length) addDoc(e.dataTransfer.files[0]);
  });
  input.addEventListener('change', ()=>{ if(input.files.length) addDoc(input.files[0]); });
  function addDoc(file){
    const row = document.createElement('tr');
    const kb = (file.size/1024).toFixed(0);
    row.innerHTML = `<td>${file.name}</td><td class="mono">${new Date().toLocaleDateString('en-IN')}</td><td class="mono">${kb} KB</td><td><span class="badge badge-amber">Under review</span></td>`;
    table.prepend(row);
    toast('Document uploaded');
  }
}

document.addEventListener('DOMContentLoaded', ()=>{
  initViews();
  initEligibility();
  initApplyForm();
  initEmiTable();
  initDocUpload();
  document.getElementById('submitServiceReq')?.addEventListener('click', ()=>{
    document.getElementById('serviceModal').classList.remove('open');
    toast('Service request submitted');
  });
});
