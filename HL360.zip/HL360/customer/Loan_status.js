(function () {
  'use strict';

  /* --------------------------------------------------------------------
     0. CONFIG
     -------------------------------------------------------------------- */
  const CONFIG = {
    STORAGE_KEY: 'hl360_loan_tracker_v2',
    TICK_MS: 1000,            // countdown chip ticks every 1s
    AUTO_ADVANCE_MS: 90 * 1000, // simulated real-time stage advance interval (demo)
    TOAST_TIMEOUT_MS: 5000,
    UPLOAD_SIM_MS: 1200,
    DATE_FMT: { day: '2-digit', month: 'short', year: 'numeric' },
    TIME_FMT: { hour: '2-digit', minute: '2-digit', hour12: true }
  };

  /* --------------------------------------------------------------------
     1. UTILITIES
     -------------------------------------------------------------------- */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $all = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  function addDays(date, days) {
    const d = new Date(date);
    d.setDate(d.getDate() + days);
    return d;
  }
  function daysBetween(a, b) {
    return Math.round((new Date(b) - new Date(a)) / 86400000);
  }
  function fmtDate(iso) {
    if (!iso) return '—';
    try { return new Date(iso).toLocaleDateString('en-IN', CONFIG.DATE_FMT); }
    catch (e) { return '—'; }
  }
  function fmtDateTime(iso) {
    if (!iso) return '—';
    try {
      const d = new Date(iso);
      return d.toLocaleDateString('en-IN', CONFIG.DATE_FMT) + ', ' + d.toLocaleTimeString('en-IN', CONFIG.TIME_FMT);
    } catch (e) { return '—'; }
  }
  function safe(fn, fallback) {
    try { return fn(); } catch (e) { console.error('[HL360]', e); return fallback; }
  }
  function uid() { return 'n_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

  /* --------------------------------------------------------------------
     2. DATA MODEL — Stage definitions (order matches data-stage 0..6
        already present on the tracker & timeline markup)
     -------------------------------------------------------------------- */
  const D = (y, m, d, h, mi) => new Date(y, m - 1, d, h || 9, mi || 0).toISOString();

  const STAGE_DEFS = [
    {
      label: 'Application Submitted', durationDays: 0, dept: 'Front Office',
      stakeholder: { name: 'Mohan Prasath', role: 'Loan Officer', dept: 'Front Office' },
      desc: 'Your loan application, along with the initial KYC and application form, has been received and logged into our system.',
      documents: ['Application Form', 'KYC Copy']
    },
    {
      label: 'Under Review', durationDays: 3, dept: 'Credit Ops Dept.',
      stakeholder: { name: 'Mohan Prasath', role: 'Loan Processing Officer', dept: 'Credit Ops Dept.' },
      desc: 'Our team is validating the basic details of your application and preparing it for document verification.',
      documents: ['Application Form', 'Income Proof']
    },
    {
      label: 'Document Verification', durationDays: 3, dept: 'Verification Cell',
      stakeholder: { name: 'Mohan Prasath', role: 'Document Verification Executive', dept: 'Verification Cell' },
      desc: 'All submitted documents are cross-checked for authenticity and completeness against bank records.',
      documents: ['Identity Proof', 'Address Proof', 'Bank Statements']
    },
    {
      label: 'Credit Evaluation', durationDays: 4, dept: 'Credit Verification',
      stakeholder: { name: 'Mohan Prasath', role: 'Credit Analyst', dept: 'Credit Verification' },
      desc: 'Your credit history, credit score and repayment capacity are assessed to determine loan eligibility.',
      documents: ['Credit Report', 'Income Proof']
    },
    {
      label: 'Technical Evaluation', durationDays: 4, dept: 'Property Valuation',
      stakeholder: { name: 'Mohan Prasath', role: 'Technical Engineer', dept: 'Property Valuation' },
      desc: 'The property is physically inspected and valued by our technical team to confirm its market worth.',
      documents: ['Property Documents', 'Site Photographs']
    },
    {
      label: 'Sanction Approved', durationDays: 3, dept: 'Branch Operations',
      stakeholder: { name: 'Mohan Prasath', role: 'Branch Manager', dept: 'Branch Operations' },
      desc: 'The branch manager reviews the complete file and grants final approval, generating your sanction letter.',
      documents: ['Sanction Letter']
    },
    {
      label: 'Disbursed', durationDays: 0, dept: 'Loan Operations',
      stakeholder: { name: 'Mohan Prasath', role: 'Disbursement Desk', dept: 'Loan Operations' },
      desc: 'The sanctioned loan amount is transferred to the seller/builder account and your loan account goes live.',
      documents: ['Disbursement Letter', 'NEFT Confirmation']
    }
  ];

  const DEFAULT_PENDING_TASKS = [
    { title: 'Upload latest bank statement', desc: "Last 3 months' statement is required to proceed with Document Verification.", due: 'Due 26 May', priority: 'High', status: 'pending', cta: 'Upload Now', kind: 'upload' },
    { title: 'Confirm co-applicant details', desc: 'Reviewed and confirmed on 23 May 2024.', due: '', priority: 'Low', status: 'completed', cta: '', kind: 'confirm' }
  ];

  function buildDefaultState() {
    const stages = STAGE_DEFS.map((def, i) => ({
      ...def,
      startedAt: i === 0 ? D(2024, 5, 20, 10, 15) : (i === 1 ? D(2024, 5, 24, 11, 30) : null),
      completedAt: i === 0 ? D(2024, 5, 20, 10, 15) : null
    }));
    return {
      currentStageIndex: 1,
      stages,
      pendingTasks: DEFAULT_PENDING_TASKS.map((t, i) => ({ id: 'task_' + i, ...t })),
      notifications: [
        { id: uid(), title: 'Application Submitted', msg: 'Your application HL1234 was received successfully.', time: D(2024, 5, 20, 10, 15), read: true },
        { id: uid(), title: 'Now Under Review', msg: 'Assigned to Mohan Prasath, Credit Ops Dept.', time: D(2024, 5, 24, 11, 30), read: true }
      ],
      lastUpdated: D(2024, 5, 24, 11, 30),
      nextAdvanceAt: Date.now() + CONFIG.AUTO_ADVANCE_MS
    };
  }

  /* --------------------------------------------------------------------
     3. STATE — load / persist (localStorage)
     -------------------------------------------------------------------- */
  let state = safe(() => {
    const raw = localStorage.getItem(CONFIG.STORAGE_KEY);
    return raw ? JSON.parse(raw) : buildDefaultState();
  }, buildDefaultState()) || buildDefaultState();

  function persist() {
    safe(() => localStorage.setItem(CONFIG.STORAGE_KEY, JSON.stringify(state)));
  }

  /* --------------------------------------------------------------------
     4. SCHEDULE ENGINE — expected/actual dates, remaining/delayed days
     -------------------------------------------------------------------- */
  function computeSchedule() {
    const stages = state.stages;
    const cur = state.currentStageIndex;
    let cursor = new Date(stages[cur].startedAt || Date.now());
    const schedule = {};
    for (let i = cur; i < stages.length; i++) {
      const start = new Date(cursor);
      const end = addDays(start, stages[i].durationDays || 0);
      schedule[i] = { start, end };
      cursor = end;
    }
    return schedule;
  }

  function overallExpectedCompletion() {
    const sched = computeSchedule();
    const last = state.stages.length - 1;
    return sched[last] ? sched[last].end.toISOString() : null;
  }

  function currentStageRemainingDays() {
    const sched = computeSchedule();
    const cur = state.currentStageIndex;
    if (!sched[cur]) return 0;
    return Math.ceil((sched[cur].end - Date.now()) / 86400000);
  }

  /* --------------------------------------------------------------------
     5. RENDER — pure DOM writes, no structural changes
     -------------------------------------------------------------------- */
  function renderStatusPill() {
    const pill = $('#statusPill');
    if (pill) pill.textContent = state.stages[state.currentStageIndex].label;
  }

  function renderLastUpdated() {
    const el = $('#lastUpdatedVal');
    if (el) el.textContent = fmtDateTime(state.lastUpdated);
  }

  function renderExpectedCompletion() {
    const el = $('#expectedCompletionVal');
    if (el) el.textContent = fmtDate(overallExpectedCompletion());
  }

  function renderHandler() {
    const cur = state.stages[state.currentStageIndex];
    const sh = cur.stakeholder;
    const initials = sh.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
    const av = $('#handlerAvatar'); if (av) av.textContent = initials;
    const nm = $('#handlerName'); if (nm) nm.textContent = sh.name;
    const rl = $('#handlerRole'); if (rl) rl.textContent = sh.role + ' · ' + sh.dept;
  }

  function renderStageCount() {
    const el = $('#stageCountBadge');
    if (el) el.textContent = `Stage ${state.currentStageIndex + 1} of ${state.stages.length} · ${state.stages[state.currentStageIndex].label}`;
  }

  function renderProgressBanner() {
    const el = $('#progressBannerText');
    if (!el) return;
    const cur = state.stages[state.currentStageIndex];
    const remaining = currentStageRemainingDays();
    if (state.currentStageIndex === state.stages.length - 1) {
      el.textContent = 'Your loan has been fully disbursed. Thank you for choosing HL360.';
    } else if (remaining < 0) {
      el.textContent = `Your application is at "${cur.label}", running ${Math.abs(remaining)} day(s) behind the usual schedule. Our team is on it.`;
    } else {
      el.textContent = `Your application is at "${cur.label}". Our team is currently working on it — expected to move forward in about ${remaining} day(s).`;
    }
  }

  function renderTracker() {
    const steps = $all('#trackerTrack .track-step');
    steps.forEach((step, i) => {
      step.classList.remove('done', 'current', 'upcoming');
      const dateEl = step.querySelector('.t-date');
      if (i < state.currentStageIndex) {
        step.classList.add('done');
        if (dateEl) dateEl.textContent = fmtDate(state.stages[i].completedAt || state.stages[i].startedAt);
      } else if (i === state.currentStageIndex) {
        step.classList.add('current');
        if (dateEl) dateEl.textContent = fmtDate(state.stages[i].startedAt);
      } else {
        step.classList.add('upcoming');
        const sched = computeSchedule();
        if (dateEl && sched[i]) dateEl.textContent = 'Exp. ' + sched[i].start.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
      }
    });
  }

  function renderTimeline() {
    const items = $all('#timelineList .t-item');
    const sched = computeSchedule();
    items.forEach((item, i) => {
      item.classList.remove('done', 'active', 'upcoming');
      const timeEl = item.querySelector('.t-time');
      const metaWrap = item.querySelector('.t-meta');
      if (metaWrap) metaWrap.remove();
      if (i < state.currentStageIndex) {
        item.classList.add('done');
        if (timeEl) { timeEl.classList.remove('expected'); timeEl.textContent = fmtDateTime(state.stages[i].completedAt || state.stages[i].startedAt); }
      } else if (i === state.currentStageIndex) {
        item.classList.add('active');
        if (timeEl) { timeEl.classList.remove('expected'); timeEl.textContent = 'Since ' + fmtDateTime(state.stages[i].startedAt); }
        const body = item.querySelector('.t-body');
        if (body) {
          const elapsed = Math.max(0, daysBetween(state.stages[i].startedAt, Date.now()));
          const meta = document.createElement('div');
          meta.className = 't-meta';
          meta.innerHTML = `<span class="turnaround-tag">${elapsed} day${elapsed === 1 ? '' : 's'} on this stage so far</span>`;
          body.appendChild(meta);
        }
      } else {
        item.classList.add('upcoming');
        if (timeEl && sched[i]) { timeEl.classList.add('expected'); timeEl.textContent = 'Expected ' + fmtDate(sched[i].start.toISOString()); }
      }
    });
  }

  function renderPendingActions() {
    const items = $all('#pendingList .pending-item');
    const pendingCount = state.pendingTasks.filter(t => t.status === 'pending').length;
    const badge = $('#pendingCountBadge');
    if (badge) badge.textContent = `${pendingCount} pending`;

    items.forEach((li, i) => {
      const task = state.pendingTasks[i];
      if (!task) return;
      const isDone = task.status === 'completed';
      li.classList.toggle('done', isDone);
      const statusEl = li.querySelector('.pending-status');
      const btn = li.querySelector('.pending-btn');
      const descEl = li.querySelector('.pending-desc');
      if (isDone) {
        if (statusEl) { statusEl.className = 'pending-status ok'; statusEl.textContent = 'Completed'; }
        if (descEl && task.kind !== 'confirm') {
          descEl.textContent = task.uploadedFileName
            ? `"${task.uploadedFileName}" uploaded on ${fmtDate(task.completedAt || new Date().toISOString())}.`
            : 'Completed on ' + fmtDate(task.completedAt || new Date().toISOString()) + '.';
        }
        if (btn) btn.remove();
        const icon = li.querySelector('.pending-icon');
        if (icon) {
          icon.className = 'pending-icon ok';
          icon.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>';
        }
      } else {
        if (statusEl) { statusEl.className = 'pending-status due'; statusEl.textContent = task.due; }
      }
    });
  }

  function renderTurnaround() {
    const list = $('#turnaroundList');
    if (!list) return;
    list.innerHTML = '';
    for (let i = 0; i < state.currentStageIndex; i++) {
      const s = state.stages[i];
      const nextStart = state.stages[i + 1] ? state.stages[i + 1].startedAt : s.completedAt;
      const days = Math.max(0, daysBetween(s.startedAt, nextStart || s.completedAt));
      const li = document.createElement('li');
      li.innerHTML = `<span class="tl-label">${s.label} → ${state.stages[i + 1] ? state.stages[i + 1].label : 'Done'}</span><span class="tl-value">${days} day${days === 1 ? '' : 's'}</span>`;
      list.appendChild(li);
    }
    const cur = state.stages[state.currentStageIndex];
    if (cur) {
      const elapsed = Math.max(0, daysBetween(cur.startedAt, Date.now()));
      const li = document.createElement('li');
      li.innerHTML = `<span class="tl-label">${cur.label} (in progress)</span><span class="tl-value live">Day ${elapsed} of ~${cur.durationDays}</span>`;
      list.appendChild(li);
    }
    // Efficiency score
    const targetDays = STAGE_DEFS.slice(0, state.currentStageIndex).reduce((s, d) => s + d.durationDays, 0);
    const actualDays = Math.max(1, daysBetween(state.stages[0].startedAt, state.stages[state.currentStageIndex].startedAt));
    let efficiency = targetDays > 0 ? Math.round((targetDays / actualDays) * 100) : 100;
    efficiency = Math.max(40, Math.min(140, efficiency));
    const effVal = $('#efficiencyValue');
    if (effVal) effVal.textContent = efficiency + '% ' + (efficiency >= 95 ? '(On Track)' : efficiency >= 75 ? '(Slightly Delayed)' : '(Delayed)');
  }

  function renderNotifBadge() {
    const unread = state.notifications.filter(n => !n.read).length;
    const dot = $('#notifDot');
    if (dot) dot.hidden = unread === 0;
  }

  function renderNotifList() {
    const body = $('#notifListBody');
    if (!body) return;
    if (!state.notifications.length) {
      body.innerHTML = '<div class="notif-empty">No notifications yet.</div>';
      return;
    }
    body.innerHTML = state.notifications.slice().reverse().map(n => `
      <div class="notif-item ${n.read ? 'read' : ''}">
        <span class="ni-dot"></span>
        <div>
          <div class="ni-title">${n.title}</div>
          <div class="ni-msg">${n.msg}</div>
          <div class="ni-time">${fmtDateTime(n.time)}</div>
        </div>
      </div>`).join('');
  }

  function renderAll() {
    renderStatusPill();
    renderLastUpdated();
    renderExpectedCompletion();
    renderHandler();
    renderStageCount();
    renderProgressBanner();
    renderTracker();
    renderTimeline();
    renderPendingActions();
    renderTurnaround();
    renderNotifBadge();
    renderNotifList();
  }

  /* --------------------------------------------------------------------
     6. TOASTS
     -------------------------------------------------------------------- */
  const ICONS = {
    success: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="20 6 9 17 4 12"/></svg>',
    info: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
    warn: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z"/></svg>',
    error: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>'
  };

  function showToast(title, msg, type) {
    type = type || 'info';
    const container = $('#toastContainer');
    if (!container) return;
    const el = document.createElement('div');
    el.className = 'toast ' + type;
    el.innerHTML = `
      <span class="toast-icon">${ICONS[type] || ICONS.info}</span>
      <div class="toast-body">
        <div class="toast-title">${title}</div>
        ${msg ? `<div class="toast-msg">${msg}</div>` : ''}
      </div>
      <button class="toast-close" aria-label="Dismiss">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>`;
    container.appendChild(el);
    const remove = () => {
      el.classList.add('closing');
      setTimeout(() => el.remove(), 220);
    };
    el.querySelector('.toast-close').addEventListener('click', remove);
    setTimeout(remove, CONFIG.TOAST_TIMEOUT_MS);
  }

  function pushNotification(title, msg) {
    state.notifications.push({ id: uid(), title, msg, time: new Date().toISOString(), read: false });
    if (state.notifications.length > 30) state.notifications.shift();
    renderNotifBadge();
    renderNotifList();
    persist();
  }

  /* --------------------------------------------------------------------
     7. STAGE DETAIL MODAL
     -------------------------------------------------------------------- */
  function openStageModal(index) {
    const s = state.stages[index];
    if (!s) return;
    const sched = computeSchedule();
    $('#modalStageBadge').textContent = `Stage ${index + 1} of ${state.stages.length}`;
    $('#modalStageTitle').textContent = s.label;
    $('#modalDesc').textContent = s.desc;
    $('#modalDept').textContent = s.dept;
    $('#modalStakeholder').textContent = `${s.stakeholder.name} — ${s.stakeholder.role}`;
    $('#modalStart').textContent = index <= state.currentStageIndex
      ? fmtDateTime(s.startedAt)
      : (sched[index] ? fmtDate(sched[index].start.toISOString()) + ' (expected)' : '—');
    $('#modalExpected').textContent = index === state.currentStageIndex && sched[index]
      ? fmtDate(sched[index].end.toISOString())
      : (index > state.currentStageIndex && sched[index] ? fmtDate(sched[index].end.toISOString()) : (s.completedAt ? '—' : '—'));
    $('#modalActual').textContent = s.completedAt ? fmtDateTime(s.completedAt) : (index < state.currentStageIndex ? fmtDateTime(s.startedAt) : 'Not yet completed');
    $('#modalDuration').textContent = s.completedAt && s.startedAt
      ? Math.max(0, daysBetween(s.startedAt, s.completedAt)) + ' day(s)'
      : (index === state.currentStageIndex ? Math.max(0, daysBetween(s.startedAt, Date.now())) + ' day(s) so far' : '—');
    $('#modalDocs').innerHTML = s.documents.map(d => `<span class="modal-doc-chip">${d}</span>`).join('');
    $('#stageModalBackdrop').classList.add('show');
  }
  function closeStageModal() {
    $('#stageModalBackdrop').classList.remove('show');
  }

  /* --------------------------------------------------------------------
     8. WORKFLOW SIMULATION — auto-advance stage over time (demo)
     -------------------------------------------------------------------- */
  function advanceStage() {
    const i = state.currentStageIndex;
    if (i >= state.stages.length - 1) return;
    const now = new Date().toISOString();
    state.stages[i].completedAt = now;
    state.stages[i + 1].startedAt = now;
    state.currentStageIndex = i + 1;
    state.lastUpdated = now;
    state.nextAdvanceAt = Date.now() + CONFIG.AUTO_ADVANCE_MS;
    persist();
    renderAll();

    const newStage = state.stages[i + 1];
    pushNotification(
      `${state.stages[i].label} Completed`,
      `Now at "${newStage.label}" — handled by ${newStage.stakeholder.name}, ${newStage.stakeholder.dept}.`
    );
    showToast(
      `${state.stages[i].label} completed ✓`,
      `Current handler: ${newStage.stakeholder.name} (${newStage.stakeholder.role})`,
      'success'
    );

    if (i + 1 === state.stages.length - 1) {
      setTimeout(() => {
        showToast('Loan Disbursed 🎉', 'Your housing loan has been fully disbursed. Congratulations!', 'success');
        pushNotification('Loan Disbursed', 'Funds have been transferred. Your loan account is now active.');
      }, 600);
    }
  }

  function tickCountdown() {
    const chip = $('#nextUpdateChip');
    if (state.currentStageIndex >= state.stages.length - 1) {
      if (chip) chip.textContent = '';
      return;
    }
    const remainingMs = state.nextAdvanceAt - Date.now();
    if (remainingMs <= 0) {
      advanceStage();
      return;
    }
    const s = Math.ceil(remainingMs / 1000);
    if (chip) chip.textContent = `Next auto-update in ${s}s`;
  }

  /* --------------------------------------------------------------------
     9. PENDING TASK ACTIONS (simulated upload / e-sign)
     -------------------------------------------------------------------- */
  function simulateAsyncAction(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async function handlePendingAction(taskIndex, btn, file) {
    const task = state.pendingTasks[taskIndex];
    if (!task || task.status === 'completed') return;
    try {
      btn.classList.add('is-loading');
      btn.disabled = true;
      await simulateAsyncAction(CONFIG.UPLOAD_SIM_MS);
      task.status = 'completed';
      task.completedAt = new Date().toISOString();
      if (file) task.uploadedFileName = file.name;
      persist();
      renderPendingActions();
      const li = btn.closest('.pending-item');
      if (li) { li.classList.add('just-completed'); setTimeout(() => li.classList.remove('just-completed'), 1400); }
      showToast(
        task.kind === 'upload' ? 'Document uploaded' : 'Task completed',
        file ? `"${file.name}" uploaded for "${task.title}".` : `"${task.title}" marked as complete.`,
        'success'
      );
      pushNotification('Task Completed', file ? `${file.name} uploaded for "${task.title}".` : `"${task.title}" has been completed.`);
    } catch (err) {
      console.error('[HL360] pending action failed', err);
      showToast('Something went wrong', 'Please try again in a moment.', 'error');
      btn.classList.remove('is-loading');
      btn.disabled = false;
    }
  }

  /* --------------------------------------------------------------------
     10. EVENT BINDING
     -------------------------------------------------------------------- */
  function bindEvents() {
    // Tracker steps -> modal
    $all('#trackerTrack .track-step').forEach(step => {
      const idx = Number(step.getAttribute('data-stage'));
      step.addEventListener('click', () => openStageModal(idx));
      step.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openStageModal(idx); } });
    });

    // Timeline items -> modal
    $all('#timelineList .t-item').forEach(item => {
      const idx = Number(item.getAttribute('data-stage'));
      item.addEventListener('click', () => openStageModal(idx));
      item.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openStageModal(idx); } });
    });

    // Handler card -> modal (current stage)
    const handlerCard = $('#handlerCard');
    if (handlerCard) {
      const openCurrent = () => openStageModal(state.currentStageIndex);
      handlerCard.addEventListener('click', openCurrent);
      handlerCard.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openCurrent(); } });
    }

    // Modal close
    const backdrop = $('#stageModalBackdrop');
    if (backdrop) {
      backdrop.addEventListener('click', e => { if (e.target === backdrop) closeStageModal(); });
      $('#modalCloseBtn').addEventListener('click', closeStageModal);
    }
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') { closeStageModal(); closeNotifDropdown(); }
    });

    // Pending task buttons (event delegation)
    const pendingList = $('#pendingList');
    const fileInput = $('#pendingUploadInput');
    let awaitingUpload = null; // { taskIndex, btn }

    if (pendingList) {
      pendingList.addEventListener('click', e => {
        const btn = e.target.closest('.pending-btn');
        if (!btn) return;
        const li = btn.closest('.pending-item');
        const idx = Number(li.getAttribute('data-task'));
        const task = state.pendingTasks[idx];
        if (task && task.kind === 'upload' && fileInput) {
          // Open the real OS file picker; the task only completes once a file is chosen.
          awaitingUpload = { taskIndex: idx, btn };
          fileInput.value = '';
          fileInput.click();
        } else {
          handlePendingAction(idx, btn);
        }
      });
    }

    if (fileInput) {
      fileInput.addEventListener('change', () => {
        if (!awaitingUpload || !fileInput.files || !fileInput.files[0]) { awaitingUpload = null; return; }
        const { taskIndex, btn } = awaitingUpload;
        const file = fileInput.files[0];
        handlePendingAction(taskIndex, btn, file);
        awaitingUpload = null;
      });
    }

    // Mobile search overlay toggle
    const mainHeader = $('#mainHeader');
    const searchToggleBtn = $('#searchToggleBtn');
    const searchCloseBtn = $('#searchCloseBtn');
    const globalSearchInput = $('#globalSearchInput');
    if (mainHeader && searchToggleBtn) {
      searchToggleBtn.addEventListener('click', () => {
        mainHeader.classList.add('search-active');
        if (globalSearchInput) setTimeout(() => globalSearchInput.focus(), 50);
      });
    }
    function closeMobileSearch() {
      if (!mainHeader) return;
      mainHeader.classList.remove('search-active');
      if (globalSearchInput) globalSearchInput.value = '';
    }
    if (searchCloseBtn) searchCloseBtn.addEventListener('click', closeMobileSearch);
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMobileSearch(); });
    window.addEventListener('resize', () => { if (window.innerWidth > 840) closeMobileSearch(); });

    // Notification bell
    const notifBtn = $('#notifBtn');
    const notifDropdown = $('#notifDropdown');
    if (notifBtn && notifDropdown) {
      notifBtn.addEventListener('click', e => {
        e.stopPropagation();
        const isOpen = notifDropdown.classList.toggle('show');
        notifBtn.setAttribute('aria-expanded', String(isOpen));
        if (isOpen) {
          state.notifications.forEach(n => {}); // no-op: keep unread until "mark all read"
        }
      });
      document.addEventListener('click', e => {
        if (!notifDropdown.contains(e.target) && e.target !== notifBtn) closeNotifDropdown();
      });
    }
    const clearBtn = $('#notifClearBtn');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        state.notifications.forEach(n => n.read = true);
        persist();
        renderNotifBadge();
        renderNotifList();
        showToast('Notifications cleared', '', 'info');
      });
    }

    // View Required Documents -> scroll to Pending Actions + highlight
    const viewDocsBtn = $('#viewDocsBtn');
    if (viewDocsBtn) {
      viewDocsBtn.addEventListener('click', () => {
        const target = document.querySelector('.pending-card');
        if (target) {
          target.scrollIntoView({ behavior: 'smooth', block: 'center' });
          target.style.transition = 'box-shadow .3s ease';
          target.style.boxShadow = '0 0 0 3px rgba(18,122,107,.35)';
          setTimeout(() => { target.style.boxShadow = ''; }, 1600);
        }
      });
    }

    // Contact Support buttons (both sidebar widget + help card)
    ['#contactSupportBtn', '#sidebarContactBtn'].forEach(sel => {
      const btn = $(sel);
      if (!btn) return;
      btn.addEventListener('click', async () => {
        const originalIsBtn = btn.classList.contains('btn');
        if (originalIsBtn) btn.classList.add('is-loading');
        btn.disabled = true;
        await simulateAsyncAction(900);
        btn.classList.remove('is-loading');
        btn.disabled = false;
        showToast('Support notified', 'A support representative will call you within 15 minutes.', 'success');
        pushNotification('Support Request Sent', 'Our team will reach out shortly.');
      });
    });

    // Download Summary -> generate & download a real text file
    const downloadBtn = $('#downloadSummaryBtn');
    if (downloadBtn) {
      downloadBtn.addEventListener('click', async () => {
        downloadBtn.classList.add('is-loading');
        downloadBtn.disabled = true;
        await simulateAsyncAction(800);
        try {
          const summary = buildSummaryText();
          const blob = new Blob([summary], { type: 'text/plain' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'HL1234-Loan-Status-Summary.txt';
          document.body.appendChild(a);
          a.click();
          a.remove();
          URL.revokeObjectURL(url);
          showToast('Summary downloaded', 'HL1234-Loan-Status-Summary.txt', 'success');
        } catch (err) {
          console.error('[HL360] download failed', err);
          showToast('Download failed', 'Please try again.', 'error');
        } finally {
          downloadBtn.classList.remove('is-loading');
          downloadBtn.disabled = false;
        }
      });
    }
  }

  function closeNotifDropdown() {
    const dd = $('#notifDropdown');
    const btn = $('#notifBtn');
    if (dd) dd.classList.remove('show');
    if (btn) btn.setAttribute('aria-expanded', 'false');
  }

  function buildSummaryText() {
    const cur = state.stages[state.currentStageIndex];
    const lines = [
      'HL360 — Housing Loan Application Summary',
      '========================================',
      'Application ID: HL1234',
      'Applicant: Mohan Prasath',
      'Loan Type: Home Loan',
      'Loan Amount: Rs. 42,50,000',
      '',
      `Current Status: ${cur.label}`,
      `Handled By: ${cur.stakeholder.name} (${cur.stakeholder.role}, ${cur.stakeholder.dept})`,
      `Last Updated: ${fmtDateTime(state.lastUpdated)}`,
      `Expected Completion: ${fmtDate(overallExpectedCompletion())}`,
      '',
      'Workflow Progress:',
      ...state.stages.map((s, i) => {
        const tag = i < state.currentStageIndex ? '[DONE]' : i === state.currentStageIndex ? '[CURRENT]' : '[UPCOMING]';
        return `  ${tag} ${s.label}${s.completedAt ? ' — completed ' + fmtDate(s.completedAt) : ''}`;
      }),
      '',
      'Pending Actions:',
      ...state.pendingTasks.map(t => `  [${t.status === 'completed' ? 'x' : ' '}] ${t.title}`),
      '',
      'Generated by HL360 on ' + fmtDateTime(new Date().toISOString())
    ];
    return lines.join('\n');
  }

  /* --------------------------------------------------------------------
     11. INIT
     -------------------------------------------------------------------- */
  function init() {
    renderAll();
    bindEvents();
    tickCountdown();
    setInterval(tickCountdown, CONFIG.TICK_MS);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();