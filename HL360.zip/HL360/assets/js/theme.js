/* =========================================================
   HL360 — shared auth guard + role badge
   Reads the logged-in user set by login.html in localStorage
   under key "hl360_user": { name, role, roleLabel }
   ========================================================= */
(function(){
  var KEY = "hl360_user";
  var path = window.location.pathname.replace(/\\/g,"/");

  function depthPrefix(){
    // count folder segments after the site root "HL360-app" (best-effort: use relative link already in <head>)
    var link = document.querySelector('link[href*="assets/css/theme.css"]');
    if(!link) return "";
    return link.getAttribute("href").replace("assets/css/theme.css","");
  }
  var ROOT = depthPrefix();

  function getUser(){
    try{ return JSON.parse(localStorage.getItem(KEY) || "null"); }catch(e){ return null; }
  }

  var ROLE_FOR_FOLDER = { "/customer/":"customer", "/legal/":"legal", "/officer/":"officer", "/admin/":"admin" };
  var requiredRole = null;
  for (var folder in ROLE_FOR_FOLDER){
    if (path.indexOf(folder) !== -1){ requiredRole = ROLE_FOR_FOLDER[folder]; break; }
  }

  var isPublicPage = path.indexOf("/login.html") !== -1 || path.endsWith("/index.html") || path === "/" ;
  var user = getUser();

  // Guard: protected module pages require a matching logged-in role
  if (requiredRole && (!user || user.role !== requiredRole)){
    window.location.href = ROOT + "login.html";
    return;
  }

  // Show a small role badge with logout on protected pages
  if (requiredRole && user){
    document.addEventListener("DOMContentLoaded", function(){
      var badge = document.createElement("div");
      badge.id = "hl360-role-badge";
      var dashboardLink = "";
      if (path.indexOf("/home.html") === -1) {
        dashboardLink = ' <a href="' + ROOT + requiredRole + '/home.html" id="hl360-dash">Dashboard</a>';
      }
      badge.innerHTML = '<span class="hl-dot"></span>' +
        'HL360 &middot; ' + (user.name || "User") + ' &middot; ' + (user.roleLabel || requiredRole) +
        dashboardLink +
        ' <a href="#" id="hl360-logout">Logout</a>';
      document.body.appendChild(badge);
      document.getElementById("hl360-logout").addEventListener("click", function(e){
        e.preventDefault();
        localStorage.removeItem(KEY);
        window.location.href = ROOT + "login.html";
      });
    });
  }
})();
