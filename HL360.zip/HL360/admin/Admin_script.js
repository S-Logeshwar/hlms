/* ==========================================================================
   HL360 Admin Dashboard (v2) — Script
   ========================================================================== */

document.addEventListener("DOMContentLoaded", function () {
  initSidebarNav();
  initSidebarToggle();
  initModalOverlayClicks();
  initLogout();
  renderKpiCards();
  renderQuickActions();
  renderRecentActivity();
  renderUsers();
  renderEmployees();
  renderLegal();
  renderOfficers();
  renderPermMatrix();
  initCharts();
});

/* ==========================================================================
   Page titles map
   ========================================================================== */
const PAGE_META = {
  dashboard:  ["Dashboard Overview", "Welcome back, monitor and manage HL360 operations"],
  users:      ["User Management", "View, search and manage customer and employee accounts"],
  employees:  ["Employee Management", "Manage staff across all departments"],
  legal:      ["Legal Team Management", "Manage legal staff, workload and verification cases"],
  officers:   ["Loan Officer Management", "Monitor officer performance and loan assignments"],
  roles:      ["Role & Permission Management", "Define roles and configure access levels"],
  profile:    ["Profile", "Manage your administrator account"]
};

/* ==========================================================================
   Sidebar navigation
   ========================================================================== */
function initSidebarNav() {
  const links = document.querySelectorAll(".nav-link[data-section]");
  const topbarProfile = document.querySelector(".topbar-profile[data-section]");

  function activate(section) {
    document.querySelectorAll(".content-section").forEach(s => s.classList.remove("active"));
    const target = document.getElementById(section);
    if (target) target.classList.add("active");

    links.forEach(l => l.classList.toggle("active", l.dataset.section === section));

    const meta = PAGE_META[section];
    if (meta) {
      document.getElementById("pageTitle").textContent = meta[0];
      document.getElementById("pageSubtitle").textContent = meta[1];
    }

    window.scrollTo({ top: 0, behavior: "smooth" });

    if (window.innerWidth <= 992) {
      document.getElementById("sidebar").classList.remove("open");
      document.getElementById("sidebarBackdrop").classList.remove("show");
    }
  }

  links.forEach(link => {
    link.addEventListener("click", () => activate(link.dataset.section));
  });

  if (topbarProfile) {
    topbarProfile.addEventListener("click", () => activate("profile"));
  }

  window.gotoSection = activate;
}

function initSidebarToggle() {
  const toggle = document.getElementById("sidebarToggle");
  const sidebar = document.getElementById("sidebar");
  const backdrop = document.getElementById("sidebarBackdrop");

  toggle.addEventListener("click", () => {
    sidebar.classList.toggle("open");
    backdrop.classList.toggle("show");
  });
  backdrop.addEventListener("click", () => {
    sidebar.classList.remove("open");
    backdrop.classList.remove("show");
  });
}

/* ==========================================================================
   Modals
   ========================================================================== */
function openModal(id) {
  document.getElementById(id).classList.add("show");
}
function closeModal(id) {
  document.getElementById(id).classList.remove("show");
}
function submitModal(id, message) {
  closeModal(id);
  showToast(message);
}
function initModalOverlayClicks() {
  document.querySelectorAll(".modal-overlay").forEach(overlay => {
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) overlay.classList.remove("show");
    });
  });
}
function initLogout() {
  document.getElementById("logoutLink").addEventListener("click", () => openModal("modalLogout"));
}

/* ==========================================================================
   Toast
   ========================================================================== */
function showToast(message) {
  const wrap = document.getElementById("toastWrap");
  const el = document.createElement("div");
  el.className = "toast-item";
  el.innerHTML = `<i class="bi bi-check-circle-fill"></i><span>${message}</span>`;
  wrap.appendChild(el);
  setTimeout(() => {
    el.style.opacity = "0";
    el.style.transition = "opacity .3s";
    setTimeout(() => el.remove(), 300);
  }, 2800);
}

/* ==========================================================================
   Dummy data
   ========================================================================== */
const users = [
  { id: "USR-10231", name: "Rahul Sinha", email: "rahul.sinha@gmail.com", phone: "+91 98765 43210", status: "active", date: "12 Jan 2026" },
  { id: "USR-10232", name: "Ananya Rao", email: "ananya.rao@gmail.com", phone: "+91 98220 11223", status: "active", date: "18 Jan 2026" },
  { id: "USR-10233", name: "Vikram Chauhan", email: "vikram.c@gmail.com", phone: "+91 90000 11122", status: "suspended", date: "22 Jan 2026" },
  { id: "USR-10234", name: "Meera Iyer", email: "meera.iyer@gmail.com", phone: "+91 99887 76655", status: "active", date: "29 Jan 2026" },
  { id: "USR-10235", name: "Suresh Pillai", email: "suresh.pillai@gmail.com", phone: "+91 91234 56780", status: "pending", date: "03 Feb 2026" },
  { id: "USR-10236", name: "Kavita Reddy", email: "kavita.reddy@gmail.com", phone: "+91 97654 32109", status: "active", date: "09 Feb 2026" },
  { id: "USR-10237", name: "Arvind Menon", email: "arvind.menon@gmail.com", phone: "+91 96543 21098", status: "inactive", date: "14 Feb 2026" },
  { id: "USR-10238", name: "Pooja Bhatt", email: "pooja.bhatt@gmail.com", phone: "+91 95432 10987", status: "active", date: "20 Feb 2026" }
];

const employees = [
  { name: "Divya Sharma", dept: "Managers", email: "divya.sharma@meridianhfl.com", joined: "04 Mar 2022", status: "active" },
  { name: "Priya Nair", dept: "Legal Team", email: "priya.nair@meridianhfl.com", joined: "11 Jun 2021", status: "active" },
  { name: "Rohit Verma", dept: "Legal Team", email: "rohit.verma@meridianhfl.com", joined: "23 Sep 2022", status: "active" },
  { name: "Sandeep Kulkarni", dept: "Loan Officers", email: "sandeep.k@meridianhfl.com", joined: "17 Jan 2023", status: "active" },
  { name: "Neha Kapoor", dept: "Support Staff", email: "neha.kapoor@meridianhfl.com", joined: "02 Apr 2023", status: "active" },
  { name: "Karan Malhotra", dept: "Legal Team", email: "karan.m@meridianhfl.com", joined: "29 Nov 2021", status: "inactive" },
  { name: "Anita Ramesh", dept: "Support Staff", email: "anita.r@meridianhfl.com", joined: "14 Feb 2024", status: "active" },
  { name: "Manoj Tiwari", dept: "Loan Officers", email: "manoj.t@meridianhfl.com", joined: "08 Aug 2022", status: "active" }
];

const legalTeam = [
  { name: "Priya Nair", cases: 14, workload: 88, pending: 5, status: "in progress" },
  { name: "Rohit Verma", cases: 9, workload: 62, pending: 2, status: "verified" },
  { name: "Ayesha Khan", cases: 11, workload: 54, pending: 4, status: "in progress" },
  { name: "Karan Malhotra", cases: 16, workload: 91, pending: 6, status: "pending" }
];

const officers = [
  { name: "Sandeep Kulkarni", assigned: 128, active: 32, completed: 96, perf: 88 },
  { name: "Manoj Tiwari", assigned: 104, active: 23, completed: 81, perf: 91 },
  { name: "Ritika Das", assigned: 87, active: 27, completed: 60, perf: 76 },
  { name: "Alok Sharma", assigned: 96, active: 26, completed: 70, perf: 82 }
];

/* ==========================================================================
   Renderers
   ========================================================================== */
function statusBadge(status) {
  const map = {
    active: "green", verified: "green", success: "green", completed: "green",
    pending: "amber", "in progress": "amber", warning: "amber",
    rejected: "red", suspended: "red", failed: "red", inactive: "gray"
  };
  const cls = map[status] || "gray";
  const label = status.replace(/\b\w/g, c => c.toUpperCase());
  return `<span class="badge-status ${cls}">${label}</span>`;
}
function initials(name) {
  return name.split(" ").map(n => n[0]).slice(0, 2).join("").toUpperCase();
}

function renderKpiCards() {
  const kpis = [
    { icon: "bi-people-fill", label: "Total Customers", value: "1,248", trend: "+4.2%", up: true, cls: "c-blue" },
    { icon: "bi-person-badge-fill", label: "Total Employees", value: "64", trend: "+2 new", up: true, cls: "c-navy" },
    { icon: "bi-person-workspace", label: "Active Loan Officers", value: "42", trend: "+1 new", up: true, cls: "c-blue" },
    { icon: "bi-briefcase-fill", label: "Active Legal Team", value: "12", trend: "Stable", up: true, cls: "c-navy" },
    { icon: "bi-hourglass-split", label: "Pending User Approvals", value: "27", trend: "-3.1%", up: false, cls: "c-amber" },
    { icon: "bi-diagram-2-fill", label: "Total System Users", value: "1,326", trend: "+3.6%", up: true, cls: "c-green" }
  ];
  document.getElementById("kpiGrid").innerHTML = kpis.map(k => `
    <div class="card kpi-card ${k.cls}">
      <div class="kpi-top">
        <div class="kpi-icon"><i class="bi ${k.icon}"></i></div>
        <div class="kpi-trend ${k.up ? "up" : "down"}"><i class="bi bi-arrow-${k.up ? "up" : "down"}-short"></i>${k.trend}</div>
      </div>
      <div class="kpi-value">${k.value}</div>
      <div class="kpi-label">${k.label}</div>
    </div>
  `).join("");
}

function renderQuickActions() {
  const actions = [
    { icon: "bi-person-badge", title: "Add Employee", desc: "Onboard new staff", action: "openModal('modalAddEmployee')" },
    { icon: "bi-person-plus", title: "Add User", desc: "Register new user account", action: "openModal('modalAddUser')" },
    { icon: "bi-shield-check", title: "Assign Role", desc: "Set role &amp; permissions", action: "gotoSection('roles')" },
    { icon: "bi-bar-chart", title: "View Reports", desc: "Open analytics overview", action: "gotoSection('dashboard')" }
  ];
  document.getElementById("quickActions").innerHTML = actions.map(a => `
    <div class="func-tile" onclick="${a.action}">
      <div class="ft-icon"><i class="bi ${a.icon}"></i></div>
      <div class="ft-title">${a.title}</div>
      <div class="ft-desc">${a.desc}</div>
    </div>
  `).join("");
}

function renderRecentActivity() {
  const rows = [
    { user: "Arjun Mehta", activity: "Suspended user account USR-10233", date: "01 Jul 2026", status: "success" },
    { user: "Divya Sharma", activity: "Assigned role \u201cLoan Officer\u201d to Alok Sharma", date: "01 Jul 2026", status: "success" },
    { user: "Karan Malhotra", activity: "Updated verification status for case #4471", date: "30 Jun 2026", status: "warning" },
    { user: "System", activity: "New employee record created: Neha Kapoor", date: "30 Jun 2026", status: "success" },
    { user: "Sandeep Kulkarni", activity: "Loan officer profile updated", date: "29 Jun 2026", status: "success" },
    { user: "Unknown", activity: "Failed login attempt on admin panel", date: "29 Jun 2026", status: "failed" }
  ];
  document.getElementById("recentActivityBody").innerHTML = rows.map(r => `
    <tr>
      <td><div class="cell-user"><div class="avatar-sq">${initials(r.user)}</div><div><div class="u-name">${r.user}</div></div></div></td>
      <td>${r.activity}</td>
      <td>${r.date}</td>
      <td>${statusBadge(r.status)}</td>
    </tr>
  `).join("");
}

function renderUsers() {
  document.getElementById("usersBody").innerHTML = users.map(c => `
    <tr>
      <td>${c.id}</td>
      <td><div class="cell-user"><div class="avatar-sq">${initials(c.name)}</div><div><div class="u-name">${c.name}</div></div></div></td>
      <td>${c.email}</td>
      <td>${c.phone}</td>
      <td>${statusBadge(c.status)}</td>
      <td>${c.date}</td>
      <td class="row-actions">
        <button title="Edit"><i class="bi bi-pencil"></i></button>
        <button title="Reset Password"><i class="bi bi-key"></i></button>
        <button title="Activate / Deactivate"><i class="bi bi-toggle2-on"></i></button>
        <button class="danger" title="Delete"><i class="bi bi-trash"></i></button>
      </td>
    </tr>
  `).join("");
}

function renderEmployees() {
  document.getElementById("employeesBody").innerHTML = employees.map(e => `
    <tr>
      <td><div class="cell-user"><div class="avatar-sq">${initials(e.name)}</div><div><div class="u-name">${e.name}</div><div class="u-sub">${e.dept}</div></div></div></td>
      <td>${e.dept}</td>
      <td>${e.email}</td>
      <td>${e.joined}</td>
      <td>${statusBadge(e.status)}</td>
      <td class="row-actions">
        <button title="Edit"><i class="bi bi-pencil"></i></button>
        <button title="Assign Department"><i class="bi bi-diagram-3"></i></button>
        <button class="danger" title="Delete"><i class="bi bi-trash"></i></button>
      </td>
    </tr>
  `).join("");
}

function renderLegal() {
  document.getElementById("legalBody").innerHTML = legalTeam.map(l => `
    <tr>
      <td><div class="cell-user"><div class="avatar-sq">${initials(l.name)}</div><div><div class="u-name">${l.name}</div></div></div></td>
      <td>${l.cases}</td>
      <td><div style="display:flex;align-items:center;gap:8px;"><div class="progress-mini"><span style="width:${l.workload}%"></span></div><span style="font-size:12px;font-weight:700;color:var(--slate-700);">${l.workload}%</span></div></td>
      <td>${l.pending}</td>
      <td>${statusBadge(l.status)}</td>
      <td class="row-actions">
        <button title="Assign Case"><i class="bi bi-briefcase"></i></button>
        <button title="Edit"><i class="bi bi-pencil"></i></button>
        <button class="danger" title="Delete"><i class="bi bi-trash"></i></button>
      </td>
    </tr>
  `).join("");
}

function renderOfficers() {
  document.getElementById("officersBody").innerHTML = officers.map(o => `
    <tr>
      <td><div class="cell-user"><div class="avatar-sq">${initials(o.name)}</div><div><div class="u-name">${o.name}</div></div></div></td>
      <td>${o.assigned}</td>
      <td>${o.active}</td>
      <td>${o.completed}</td>
      <td><div style="display:flex;align-items:center;gap:8px;"><div class="progress-mini"><span style="width:${o.perf}%"></span></div><span style="font-size:12px;font-weight:700;color:var(--slate-700);">${o.perf}%</span></div></td>
      <td class="row-actions">
        <button title="Assign Loan"><i class="bi bi-clipboard-check"></i></button>
        <button title="Edit"><i class="bi bi-pencil"></i></button>
        <button class="danger" title="Delete"><i class="bi bi-trash"></i></button>
      </td>
    </tr>
  `).join("");
}

function renderPermMatrix() {
  const roles = [
    { role: "Administrator", perms: [1,1,1,1,1,1] },
    { role: "Loan Officer", perms: [1,1,1,0,1,0] },
    { role: "Legal Team", perms: [1,0,1,0,1,0] },
    { role: "Customer", perms: [1,0,0,0,0,0] }
  ];
  document.getElementById("permBody").innerHTML = roles.map(r => `
    <tr>
      <td>${r.role}</td>
      ${r.perms.map(p => `<td><span class="perm-check ${p ? "on" : ""}">${p ? '<i class="bi bi-check-lg"></i>' : ""}</span></td>`).join("")}
    </tr>
  `).join("");
}

/* ==========================================================================
   Charts (Chart.js)
   ========================================================================== */
function initCharts() {
  const colors = {
    blue: "#2563eb",
    blueSoft: "rgba(37,99,235,0.12)",
    navy: "#0b2149",
    green: "#0f9d58",
    amber: "#c9781f",
    red: "#d93636",
    grid: "#eef2f8",
    text: "#5b6b8c"
  };
  Chart.defaults.font.family = "Inter, sans-serif";
  Chart.defaults.font.size = 11.5;
  Chart.defaults.color = colors.text;

  const months = ["Nov","Dec","Jan","Feb","Mar","Apr","May","Jun"];

  // Monthly user registration (customers vs employees)
  new Chart(document.getElementById("chartUserReg"), {
    type: "bar",
    data: {
      labels: months,
      datasets: [
        { label: "Customers", data: [62,74,58,81,96,88,104,118], backgroundColor: colors.blue, borderRadius: 6, barPercentage: .6 },
        { label: "Employees", data: [3,2,4,1,3,2,5,2], backgroundColor: colors.navy, borderRadius: 6, barPercentage: .6 }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: "top", align: "end", labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true, pointStyle: "circle" } } },
      scales: {
        x: { grid: { display: false }, stacked: true },
        y: { grid: { color: colors.grid }, stacked: true }
      }
    }
  });

  // Employee distribution doughnut
  const empDist = { labels: ["Loan Officers","Legal Team","Support Staff","Managers"], values: [42,12,7,3], colors: [colors.blue, colors.navy, colors.green, colors.amber] };
  new Chart(document.getElementById("chartEmpDist"), {
    type: "doughnut",
    data: {
      labels: empDist.labels,
      datasets: [{ data: empDist.values, backgroundColor: empDist.colors, borderWidth: 0, hoverOffset: 4 }]
    },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: "68%",
      plugins: { legend: { display: false } }
    }
  });
  document.getElementById("empDistLegend").innerHTML = empDist.labels.map((l,i) => `
    <div class="legend-item"><span class="legend-dot" style="background:${empDist.colors[i]}"></span>${l}</div>
  `).join("");
}
