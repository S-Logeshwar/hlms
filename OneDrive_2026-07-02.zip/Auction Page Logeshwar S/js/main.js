/* ==========================================================================
   HLMS Auction Module — shared layout + interactions
   ========================================================================== */

const NAV_ITEMS = [
  { href: 'dashboard.html', icon: 'fa-grid-2', label: 'Dashboard' },
  { href: 'auctions.html', icon: 'fa-gavel', label: 'Auctions' },
  { href: 'my-bids.html', icon: 'fa-hand-holding-dollar', label: 'My Bids' },
  { href: 'emd-payment.html', icon: 'fa-credit-card', label: 'Payments' },
  { href: 'auction-schedule.html', icon: 'fa-calendar-days', label: 'Schedule' },
  { href: 'auction-result.html', icon: 'fa-flag-checkered', label: 'Results' },
  { href: 'profile.html', icon: 'fa-user', label: 'Profile' },
  { href: 'support.html', icon: 'fa-headset', label: 'Support' },
];

function renderSidebar() {
  const mount = document.getElementById('sidebar');
  if (!mount) return;
  const current = document.body.dataset.page || '';
  const links = NAV_ITEMS.map(item => {
    const active = item.href.replace('.html', '') === current ? ' active' : '';
    return `<a class="nav-link${active}" href="${item.href}"><i class="fa-solid ${item.icon}"></i><span>${item.label}</span></a>`;
  }).join('');

  mount.innerHTML = `
    <div class="sidebar-brand">
      <div class="mark">HL</div>
      <div>
        <div class="name">HLMS Bank</div>
        <div class="sub">Auction Portal</div>
      </div>
    </div>
    <div class="nav-group-label">Menu</div>
    ${links}
    <div class="sidebar-footer">
      <a class="nav-link" href="auction-login.html"><i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span></a>
    </div>
  `;
}

function renderTopbar() {
  const mount = document.getElementById('topbar');
  if (!mount) return;
  mount.innerHTML = `
    <div class="search-box">
      <i class="fa-solid fa-magnifying-glass"></i>
      <input type="text" placeholder="Search properties, locations..." />
    </div>
    <div class="topbar-right">
      <button class="icon-btn" title="Notifications"><i class="fa-regular fa-bell"></i><span class="dot"></span></button>
      <button class="icon-btn" title="Messages"><i class="fa-regular fa-comment-dots"></i></button>
      <div class="user-chip">
        <div class="avatar">LM</div>
        <div>
          <div class="uname">Logeshwar M</div>
          <div class="urole">Bidder</div>
        </div>
        <i class="fa-solid fa-chevron-down" style="font-size:10px;color:var(--faint);margin-left:2px;"></i>
      </div>
    </div>
  `;
}

function initLayout() {
  renderSidebar();
  renderTopbar();
}

/* ---------- Generic countdown ---------- */
function startCountdown(el, endTime, onTick) {
  function tick() {
    const diff = Math.max(0, endTime - Date.now());
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    if (onTick) onTick(el, { d, h, m, s, diff });
    if (diff <= 0) clearInterval(timer);
  }
  tick();
  const timer = setInterval(tick, 1000);
  return timer;
}

function pad(n) { return String(n).padStart(2, '0'); }

/* ---------- Init small countdown chips (property cards) ---------- */
function initChipCountdowns() {
  document.querySelectorAll('[data-countdown-end]').forEach(el => {
    const end = Date.now() + Number(el.dataset.countdownEnd) * 1000;
    startCountdown(el, end, (node, t) => {
      node.textContent = `${pad(t.h)}:${pad(t.m)}:${pad(t.s)}`;
    });
  });
}

/* ---------- Init big countdown blocks (schedule / login page) ---------- */
function initBlockCountdowns() {
  document.querySelectorAll('[data-block-countdown]').forEach(el => {
    const end = Date.now() + Number(el.dataset.blockCountdown) * 1000;
    const dEl = el.querySelector('.c-d'), hEl = el.querySelector('.c-h'),
          mEl = el.querySelector('.c-m'), sEl = el.querySelector('.c-s');
    startCountdown(el, end, (node, t) => {
      if (dEl) dEl.textContent = pad(t.d);
      if (hEl) hEl.textContent = pad(t.h);
      if (mEl) mEl.textContent = pad(t.m);
      if (sEl) sEl.textContent = pad(t.s);
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initLayout();
  initChipCountdowns();
  initBlockCountdowns();
});
