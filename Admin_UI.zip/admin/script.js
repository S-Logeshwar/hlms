/* ===== Shared UI utilities (no backend — all data is local/dummy) ===== */

// Sidebar toggle (mobile)
function initSidebarToggle(){
  const toggle = document.querySelector('.menu-toggle');
  const sidebar = document.querySelector('.sidebar');
  if(!toggle || !sidebar) return;
  toggle.addEventListener('click', ()=> sidebar.classList.toggle('open'));
  document.addEventListener('click', (e)=>{
    if(window.innerWidth<=900 && sidebar.classList.contains('open')
      && !sidebar.contains(e.target) && !toggle.contains(e.target)){
      sidebar.classList.remove('open');
    }
  });
}

// Tabs: any [data-tabs] container with .tab-btn[data-tab] + .tab-panel[data-panel]
function initTabs(){
  document.querySelectorAll('[data-tabs]').forEach(group=>{
    const btns = group.querySelectorAll('.tab-btn');
    btns.forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const target = btn.getAttribute('data-tab');
        group.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        const panelContainer = group.getAttribute('data-panels') || group.getAttribute('data-tabs');
        document.querySelectorAll(`.tab-panel[data-group="${panelContainer}"]`).forEach(p=>{
          p.classList.toggle('active', p.getAttribute('data-panel')===target);
        });
      });
    });
  });
}

// Toast notifications
function toast(message, opts={}){
  let wrap = document.querySelector('.toast-wrap');
  if(!wrap){
    wrap = document.createElement('div');
    wrap.className='toast-wrap';
    document.body.appendChild(wrap);
  }
  const el = document.createElement('div');
  el.className='toast';
  el.textContent = message;
  wrap.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transition='opacity .3s'; setTimeout(()=>el.remove(),300); }, opts.duration||2600);
}

// Modal open/close via [data-modal-open]/[data-modal-close] + target id
function initModals(){
  document.querySelectorAll('[data-modal-open]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-modal-open');
      document.getElementById(id)?.classList.add('open');
    });
  });
  document.querySelectorAll('[data-modal-close]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      btn.closest('.modal-overlay')?.classList.remove('open');
    });
  });
  document.querySelectorAll('.modal-overlay').forEach(ov=>{
    ov.addEventListener('click', (e)=>{ if(e.target===ov) ov.classList.remove('open'); });
  });
}

// Simple local "storage" helper (per-app namespace, no backend)
const LocalStore = {
  get(key, fallback){
    try{
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    }catch(e){ return fallback; }
  },
  set(key, value){
    try{ localStorage.setItem(key, JSON.stringify(value)); }catch(e){}
  }
};

function formatINR(num){
  return '₹' + Number(num).toLocaleString('en-IN');
}

document.addEventListener('DOMContentLoaded', ()=>{
  initSidebarToggle();
  initTabs();
  initModals();
});

/* ===== Admin logic ===== */
function initViews(){
  const links = document.querySelectorAll('.nav a[data-view]');
  const views = document.querySelectorAll('.view[data-view]');
  const titleEl = document.getElementById('pageTitle');
  const subEl = document.getElementById('pageSub');
  const titles = {
    dashboard: ['Dashboard','Platform health and activity'],
    users: ['User Management','Manage accounts across every role'],
    roles: ['Roles & Permissions','Control feature access by role'],
    audit: ['Audit Logs','A record of sensitive actions across the platform'],
    notifications: ['Notifications','Configure automated communication channels'],
    settings: ['System Settings','Loan configuration and platform security']
  };
  function activate(view){
    views.forEach(v=>v.classList.toggle('active', v.getAttribute('data-view')===view));
    links.forEach(l=>l.classList.toggle('active', l.getAttribute('data-view')===view));
    if(titles[view]){ titleEl.textContent=titles[view][0]; subEl.textContent=titles[view][1]; }
    document.querySelector('.sidebar')?.classList.remove('open');
    window.scrollTo({top:0,behavior:'smooth'});
  }
  links.forEach(l=>l.addEventListener('click', e=>{e.preventDefault(); activate(l.getAttribute('data-view'));}));
}

const badgeForRole = {
  'Customer':'badge-blue','Loan Officer':'badge-amber','Legal Team':'badge-slate','Administrator':'badge-coral'
};

document.addEventListener('DOMContentLoaded', ()=>{
  initViews();

  document.getElementById('createUserBtn')?.addEventListener('click', ()=>{
    const name = document.getElementById('newUserName').value.trim();
    const email = document.getElementById('newUserEmail').value.trim();
    const role = document.getElementById('newUserRole').value;
    if(!name || !email){ toast('Enter a name and email'); return; }
    const row = document.createElement('tr');
    row.innerHTML = `<td>${name}</td><td class="cell-sub">${email}</td><td><span class="badge ${badgeForRole[role]}">${role}</span></td><td><span class="badge badge-green">Active</span></td><td><button class="btn btn-ghost btn-sm">Manage</button></td>`;
    document.getElementById('userTable').prepend(row);
    document.getElementById('userModal').classList.remove('open');
    toast(`User ${name} created as ${role}`);
  });

  document.getElementById('savePerms')?.addEventListener('click', ()=> toast('Permission changes saved'));
  document.getElementById('saveNotifSettings')?.addEventListener('click', ()=> toast('Notification settings saved'));
  document.getElementById('sendBroadcast')?.addEventListener('click', ()=> toast('Broadcast sent'));
  document.getElementById('saveLoanConfig')?.addEventListener('click', ()=> toast('Loan configuration saved'));
  document.getElementById('saveSecurity')?.addEventListener('click', ()=> toast('Security settings saved'));
});
