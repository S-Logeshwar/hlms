document.addEventListener('DOMContentLoaded', function () {

  /* ============================================================
     SIDEBAR PAGE NAVIGATION (Dashboard, Apply for Loan, etc.)
     ============================================================ */
  const navItems = document.querySelectorAll('.nav-item');
  const pages = document.querySelectorAll('.page');
  const sidebar = document.getElementById('sidebar');
  const menuToggle = document.getElementById('menuToggle');

  navItems.forEach(item => {
    item.addEventListener('click', function () {
      const target = this.dataset.page;

      navItems.forEach(i => i.classList.remove('active'));
      this.classList.add('active');

      pages.forEach(p => {
        p.classList.toggle('active', p.dataset.page === target);
      });

      // close sidebar on mobile after selecting a page
      sidebar.classList.remove('open');
    });
  });

  if (menuToggle) {
    menuToggle.addEventListener('click', function () {
      sidebar.classList.toggle('open');
    });
  }

  /* ============================================================
     LOAN APPLICATION FORM (5-step wizard)
     Only runs if the loan form exists on the page.
     ============================================================ */
  const form = document.getElementById('loanForm');
  if (!form) return;

  const panels = Array.from(document.querySelectorAll('.form-panel'));
  const steps = Array.from(document.querySelectorAll('.stepper .step'));
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const submitBtn = document.getElementById('submitBtn');
  const progressFill = document.getElementById('progressFill');
  const progressStepText = document.getElementById('progressStepText');
  const progressPercentText = document.getElementById('progressPercentText');

  const totalSteps = panels.length;
  let currentStep = 1;

  // ---------- Same as current address checkbox ----------
  const sameCheckbox = document.getElementById('samePermanent');
  const permanentGroup = document.getElementById('permanentAddressGroup');
  const currentAddress = document.getElementById('currentAddress');
  const permanentAddress = document.getElementById('permanentAddress');

  sameCheckbox.addEventListener('change', function () {
    if (this.checked) {
      permanentAddress.value = currentAddress.value;
      permanentGroup.style.display = 'none';
      permanentAddress.removeAttribute('required');
    } else {
      permanentGroup.style.display = 'block';
      permanentAddress.setAttribute('required', 'required');
    }
  });

  // ---------- Navigation ----------
  function showStep(step) {
    panels.forEach(panel => {
      panel.classList.toggle('active', Number(panel.dataset.panel) === step);
    });

    steps.forEach(s => {
      const sNum = Number(s.dataset.step);
      s.classList.toggle('active', sNum === step);
      s.classList.toggle('completed', sNum < step);
    });

    prevBtn.style.display = step === 1 ? 'none' : 'inline-block';
    nextBtn.style.display = step === totalSteps ? 'none' : 'inline-block';
    submitBtn.style.display = step === totalSteps ? 'inline-block' : 'none';

    const percent = Math.round((step / totalSteps) * 100);
    progressFill.style.width = percent + '%';
    progressStepText.textContent = `Step ${step} of ${totalSteps}`;
    progressPercentText.textContent = percent + '%';

    if (step === totalSteps) {
      populateReview();
    }
  }

  function validateCurrentStep() {
    const currentPanel = panels.find(p => Number(p.dataset.panel) === currentStep);
    const fields = currentPanel.querySelectorAll('input, select, textarea');
    let firstInvalid = null;

    for (const field of fields) {
      if (!field.checkValidity()) {
        if (!firstInvalid) firstInvalid = field;
      }
    }

    if (firstInvalid) {
      firstInvalid.reportValidity();
      return false;
    }
    return true;
  }

  nextBtn.addEventListener('click', function () {
    if (!validateCurrentStep()) return;
    if (currentStep < totalSteps) {
      currentStep++;
      showStep(currentStep);
    }
  });

  prevBtn.addEventListener('click', function () {
    if (currentStep > 1) {
      currentStep--;
      showStep(currentStep);
    }
  });

  // ---------- Review summary ----------
  function labelFor(input) {
    if (input.closest('.form-group')) {
      const lbl = input.closest('.form-group').querySelector('label');
      if (lbl) return lbl.textContent.replace('(Optional)', '').trim();
    }
    return input.name;
  }

  function buildReview(panelNum, containerId) {
    const panel = panels.find(p => Number(p.dataset.panel) === panelNum);
    const container = document.getElementById(containerId);
    container.innerHTML = '';

    const seen = new Set();
    const groups = panel.querySelectorAll('.form-group, .upload-box');

    groups.forEach(group => {
      const input = group.querySelector('input, select, textarea');
      if (!input || seen.has(input.name)) return;

      let value = '';
      if (input.type === 'radio') {
        const checked = panel.querySelector(`input[name="${input.name}"]:checked`);
        value = checked ? checked.closest('.radio-option').querySelector('span').textContent : '';
      } else if (input.type === 'checkbox') {
        return; // skip checkboxes in summary
      } else if (input.type === 'file') {
        value = input.files && input.files.length ? input.files[0].name : 'Not uploaded';
      } else {
        value = input.value || '';
      }

      seen.add(input.name);

      const item = document.createElement('div');
      item.className = 'review-item';
      item.innerHTML = `<span class="review-label">${labelFor(input)}</span>${value || '—'}`;
      container.appendChild(item);
    });
  }

  function populateReview() {
    buildReview(1, 'reviewLoan');
    buildReview(2, 'reviewPersonal');
    buildReview(3, 'reviewEmployment');
    buildReview(4, 'reviewDocuments');
  }

  // ---------- Submit ----------
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!validateCurrentStep()) return;

    alert('Application submitted successfully! Our team will review your details and contact you shortly.');
    // Replace the line above with an actual fetch()/API call to your backend.
  });

  showStep(currentStep);
});
