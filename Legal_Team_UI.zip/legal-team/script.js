/* ===== Shared UI utilities (no backend — all data is local/dummy) ===== */

// Sidebar toggle (mobile)
function initSidebarToggle(){
  const toggle = document.querySelector('.menu-toggle');
  const sidebar = document.querySelector('.sidebar');
  if(!toggle || !sidebar) return;
  toggle.addEventListener('click', ()=> sidebar.classList.toggle('open'));
  document.addEventListener('click', (e)=>{
    if(window.innerWidth<=900 && sidebar.classList.contains('open')
      && !sidebar.contains(e.target) && !toggle.contains(e.target)){
      sidebar.classList.remove('open');
    }
  });
}

// Tabs: any [data-tabs] container with .tab-btn[data-tab] + .tab-panel[data-panel]
function initTabs(){
  document.querySelectorAll('[data-tabs]').forEach(group=>{
    const btns = group.querySelectorAll('.tab-btn');
    btns.forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const target = btn.getAttribute('data-tab');
        group.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        const panelContainer = group.getAttribute('data-panels') || group.getAttribute('data-tabs');
        document.querySelectorAll(`.tab-panel[data-group="${panelContainer}"]`).forEach(p=>{
          p.classList.toggle('active', p.getAttribute('data-panel')===target);
        });
      });
    });
  });
}

// Toast notifications
function toast(message, opts={}){
  let wrap = document.querySelector('.toast-wrap');
  if(!wrap){
    wrap = document.createElement('div');
    wrap.className='toast-wrap';
    document.body.appendChild(wrap);
  }
  const el = document.createElement('div');
  el.className='toast';
  el.textContent = message;
  wrap.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transition='opacity .3s'; setTimeout(()=>el.remove(),300); }, opts.duration||2600);
}

// Modal open/close via [data-modal-open]/[data-modal-close] + target id
function initModals(){
  document.querySelectorAll('[data-modal-open]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-modal-open');
      document.getElementById(id)?.classList.add('open');
    });
  });
  document.querySelectorAll('[data-modal-close]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      btn.closest('.modal-overlay')?.classList.remove('open');
    });
  });
  document.querySelectorAll('.modal-overlay').forEach(ov=>{
    ov.addEventListener('click', (e)=>{ if(e.target===ov) ov.classList.remove('open'); });
  });
}

// Simple local "storage" helper (per-app namespace, no backend)
const LocalStore = {
  get(key, fallback){
    try{
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    }catch(e){ return fallback; }
  },
  set(key, value){
    try{ localStorage.setItem(key, JSON.stringify(value)); }catch(e){}
  }
};

function formatINR(num){
  return '₹' + Number(num).toLocaleString('en-IN');
}

document.addEventListener('DOMContentLoaded', ()=>{
  initSidebarToggle();
  initTabs();
  initModals();
});

/* ===== Legal Team logic ===== */
function initViews(){
  const links = document.querySelectorAll('.nav a[data-view]');
  const views = document.querySelectorAll('.view[data-view]');
  const titleEl = document.getElementById('pageTitle');
  const subEl = document.getElementById('pageSub');
  const titles = {
    dashboard: ['Dashboard','Legal review queue overview'],
    docket: ['Case Docket','All matters currently assigned to legal'],
    verification: ['Document Verification','Verify property and loan-related documents'],
    mortgage: ['Mortgage Records','Property and agreement records under mortgage'],
    notices: ['Notices & Compliance','Review and track legal notices'],
    auction: ['Auction Clearance','Confirm legal eligibility before asset auctions']
  };
  function activate(view){
    views.forEach(v=>v.classList.toggle('active', v.getAttribute('data-view')===view));
    links.forEach(l=>l.classList.toggle('active', l.getAttribute('data-view')===view));
    if(titles[view]){ titleEl.textContent=titles[view][0]; subEl.textContent=titles[view][1]; }
    document.querySelector('.sidebar')?.classList.remove('open');
    window.scrollTo({top:0,behavior:'smooth'});
  }
  links.forEach(l=>l.addEventListener('click', e=>{e.preventDefault(); activate(l.getAttribute('data-view'));}));
  document.querySelectorAll('[data-goto]').forEach(b=>b.addEventListener('click', ()=>activate(b.getAttribute('data-goto'))));
}

document.addEventListener('DOMContentLoaded', ()=>{
  initViews();
  document.getElementById('submitVerify')?.addEventListener('click', ()=>{
    const outcome = document.getElementById('verifyOutcome').value;
    toast(`Verification recorded: ${outcome}`);
  });
  document.getElementById('saveCaseNotes')?.addEventListener('click', ()=>{
    document.getElementById('caseModal').classList.remove('open');
    toast('Case notes saved');
  });
  document.getElementById('submitLegalNotice')?.addEventListener('click', ()=>{
    document.getElementById('issueNoticeModal').classList.remove('open');
    toast('Legal notice issued');
  });
  document.getElementById('clearAuctionBtn')?.addEventListener('click', (e)=>{
    e.target.closest('tr').querySelector('td:nth-child(4)').textContent = 'Cleared';
    toast('Asset cleared for auction');
  });
});
