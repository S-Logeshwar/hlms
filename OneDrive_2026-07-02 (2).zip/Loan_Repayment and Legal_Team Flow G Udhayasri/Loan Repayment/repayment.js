/* ---------- Config ---------- */
const PRINCIPAL = 4250000;
const ANNUAL_RATE = 8.5;
const MONTHLY_RATE = ANNUAL_RATE / 12 / 100;
const TENURE_MONTHS = 240;
const EMI = 36822;
const START_DATE = new Date(2024, 4, 20); // 20 May 2024 disbursement
const FIRST_DUE = new Date(2024, 5, 5);   // 05 Jun 2024

let simMonthsElapsed = 25;   // simulated "today" ~ Jul 2026, 25 months after first due
let paymentsMade = 22;       // a few behind, to demonstrate overdue detection
let history = [];            // {ref, date, installment, amount, mode, status}
let refCounter = 1;

/* ---------- Build amortization schedule ---------- */
function buildSchedule(){
  const rows = [];
  let balance = PRINCIPAL;
  for(let i=1;i<=TENURE_MONTHS;i++){
    const interest = Math.round(balance * MONTHLY_RATE);
    let principalPart = EMI - interest;
    if(i === TENURE_MONTHS || principalPart > balance) principalPart = balance;
    balance = Math.max(0, balance - principalPart);
    const due = new Date(FIRST_DUE);
    due.setMonth(due.getMonth() + (i-1));
    rows.push({
      n:i, due, emi: (i===TENURE_MONTHS ? principalPart+interest : EMI),
      principal: principalPart, interest, balanceAfter: balance
    });
  }
  return rows;
}
const schedule = buildSchedule();

function fmtINR(n){
  return '₹' + Math.round(n).toLocaleString('en-IN');
}
function fmtDate(d){
  return d.toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'});
}

/* "Today" for overdue logic = FIRST_DUE + simMonthsElapsed months */
function today(){
  const t = new Date(FIRST_DUE);
  t.setMonth(t.getMonth() + simMonthsElapsed);
  return t;
}

function statusFor(row){
  if(row.n <= paymentsMade) return 'paid';
  if(row.due < today()) return 'overdue';
  return 'upcoming';
}

/* ---------- Render: schedule table ---------- */
function renderSchedule(){
  const body = document.getElementById('scheduleBody');
  body.innerHTML = '';
  schedule.forEach(row=>{
    const st = statusFor(row);
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${row.n}</td>
      <td>${fmtDate(row.due)}</td>
      <td>${fmtINR(row.emi)}</td>
      <td>${fmtINR(row.principal)}</td>
      <td>${fmtINR(row.interest)}</td>
      <td>${fmtINR(row.balanceAfter)}</td>
      <td><span class="badge ${st}">${st.charAt(0).toUpperCase()+st.slice(1)}</span></td>`;
    body.appendChild(tr);
  });
}

/* ---------- Render: due-installment select ---------- */
function renderDueSelect(){
  const sel = document.getElementById('dueSelect');
  sel.innerHTML = '';
  schedule.filter(r => r.n > paymentsMade).slice(0,12).forEach(row=>{
    const st = statusFor(row);
    const opt = document.createElement('option');
    opt.value = row.n;
    opt.textContent = `#${row.n} · Due ${fmtDate(row.due)} · ${fmtINR(row.emi)}${st==='overdue' ? '  (Overdue)':''}`;
    sel.appendChild(opt);
  });
  // document.getElementById('payAmount').value = EMI;
  syncAmountToSelectedInstallment();
}

function syncAmountToSelectedInstallment(){
  const sel = document.getElementById('dueSelect');
  const amountEl = document.getElementById('payAmount');
  const instN = parseInt(sel.value, 10);
  const row = schedule.find(r => r.n === instN);
  amountEl.value = row ? row.emi : '';
}


/* ---------- Render: history ---------- */
function renderHistory(){
  const body = document.getElementById('historyBody');
  body.innerHTML = '';
  const officerOn = document.getElementById('officerToggle').checked;
  [...history].reverse().forEach(h=>{
    const tr = document.createElement('tr');
    const canReverse = officerOn && h.status === 'Success';
    tr.innerHTML = `
      <td>${h.ref}</td>
      <td>${h.date}</td>
      <td>#${h.installment}</td>
      <td>${fmtINR(h.amount)}</td>
      <td>${h.mode}</td>
      <td><span class="badge ${h.status==='Success'?'paid':'rejected'}">${h.status}</span></td>
      <td>${canReverse ? `<button class="btn ghost" style="padding:5px 10px;font-size:11px;" data-ref="${h.ref}">Reverse</button>` : `<span class="badge locked">🔒 Locked</span>`}</td>`;
    body.appendChild(tr);
  });
  body.querySelectorAll('button[data-ref]').forEach(btn=>{
    btn.onclick = ()=> reversePayment(btn.getAttribute('data-ref'));
  });
}

/* ---------- Render: stat cards / balance panel ---------- */
function renderStats(){
  const outstandingRow = schedule[Math.max(0,paymentsMade-1)];
  const balance = paymentsMade === 0 ? PRINCIPAL : outstandingRow.balanceAfter;
  document.getElementById('statBalance').textContent = fmtINR(balance);
  document.getElementById('outstandingBig').textContent = fmtINR(balance);
  document.getElementById('principalRepaid').textContent = fmtINR(PRINCIPAL - balance);

  const nextRow = schedule.find(r=>r.n>paymentsMade);
  if(nextRow){
    document.getElementById('statNextDue').textContent = fmtDate(nextRow.due);
    document.getElementById('statNextAmt').textContent = fmtINR(nextRow.emi) + ' due';
  } else {
    document.getElementById('statNextDue').textContent = 'Loan closed';
    document.getElementById('statNextAmt').textContent = '—';
  }

  const overdueCount = schedule.filter(r => statusFor(r) === 'overdue').length;
  document.getElementById('statOverdue').textContent = overdueCount;
  document.getElementById('statPaid').textContent = `${paymentsMade} / ${TENURE_MONTHS}`;
}

function renderAll(){
  renderSchedule();
  renderDueSelect();
  renderHistory();
  renderStats();
}

/* ---------- Seed initial payment history for the already-paid EMIs ---------- */
function seedHistory(){
  for(let i=1;i<=paymentsMade;i++){
    const row = schedule[i-1];
    const recordedOn = new Date(row.due);
    history.push({
      ref: 'PAY' + String(refCounter++).padStart(6,'0'),
      date: fmtDate(recordedOn),
      installment: i,
      amount: row.emi,
      mode: i % 4 === 0 ? 'UPI' : 'Auto-debit',
      status: 'Success'
    });
  }
}
seedHistory();

/* ==========================================================
   US-LRM-01: field-level validation
   Each field has its own rule set, checked live and on submit.
   ========================================================== */

const REF_REQUIRED_MODES = ['NEFT', 'Cheque'];

const els = {
  due:    document.getElementById('dueSelect'),
  amount: document.getElementById('payAmount'),
  mode:   document.getElementById('payMode'),
  ref:    document.getElementById('payRef'),
  refField: document.getElementById('refField'),
};

function setFieldState(inputEl, errorEl, message){
  const errBox = document.getElementById(errorEl);
  if(message){
    inputEl.classList.add('invalid');
    inputEl.classList.remove('valid');
    errBox.textContent = message;
    errBox.classList.add('show');
    return false;
  }
  inputEl.classList.remove('invalid');
  inputEl.classList.add('valid');
  errBox.classList.remove('show');
  errBox.textContent = '';
  return true;
}

/* ---- Individual field validators ---- */

function validateDue(){
  const raw = els.due.value;
  if(!raw){
    return setFieldState(els.due, 'dueSelectError', 'Please select an installment.');
  }
  const instN = parseInt(raw, 10);
  const row = schedule.find(r => r.n === instN);
  if(!row){
    return setFieldState(els.due, 'dueSelectError', 'Selected installment is not valid.');
  }
  if(instN <= paymentsMade){
    return setFieldState(els.due, 'dueSelectError', `Installment #${instN} is already marked Paid.`);
  }
  if(instN !== paymentsMade + 1){
    return setFieldState(els.due, 'dueSelectError', `Installments must be paid in order. Pay #${paymentsMade+1} first.`);
  }
  return setFieldState(els.due, 'dueSelectError', '');
}

function validateAmount(){
  const raw = els.amount.value.trim();
  const instN = parseInt(els.due.value, 10);
  const row = schedule.find(r => r.n === instN);
  if(!row || !raw){
    return setFieldState(els.amount, 'payAmountError', 'Select an installment to populate the amount.');
  }
  return setFieldState(els.amount, 'payAmountError', '');
}

function validateMode(){
  const mode = els.mode.value;
  const ok = setFieldState(els.mode, 'payModeError', mode ? '' : 'Select a payment mode.');
  toggleRefField();
  return ok;
}

function toggleRefField(){
  const needsRef = REF_REQUIRED_MODES.includes(els.mode.value);
  els.refField.hidden = !needsRef;
  if(!needsRef){
    els.ref.value = '';
    setFieldState(els.ref, 'payRefError', '');
  }
}

function validateRef(){
  const needsRef = REF_REQUIRED_MODES.includes(els.mode.value);
  if(!needsRef) return true;
  const raw = els.ref.value.trim();
  if(!raw){
    return setFieldState(els.ref, 'payRefError', `Reference number is required for ${els.mode.value} payments.`);
  }
  if(!/^[A-Za-z0-9]{6,20}$/.test(raw)){
    return setFieldState(els.ref, 'payRefError', 'Use 6–20 letters/numbers only, no spaces or symbols.');
  }
  const hasLetter = /[A-Za-z]/.test(raw);
  const hasNumber = /[0-9]/.test(raw);
  if(!hasLetter || !hasNumber){
    return setFieldState(els.ref, 'payRefError', 'Must be a combination of letters and numbers, e.g. NEFT2026070212345.');
  }
  return setFieldState(els.ref, 'payRefError', '');
}

/* ---- Live validation as the user interacts ---- */
els.due.addEventListener('change', () => { syncAmountToSelectedInstallment(); validateDue(); validateAmount(); });
els.mode.addEventListener('change', () => { validateMode(); validateRef(); });
els.ref.addEventListener('input', validateRef);

/* ---- Submit: re-run every validator, block on first failure ---- */
document.getElementById('payForm').addEventListener('submit', function(e){
  e.preventDefault();
  const msg = document.getElementById('payMsg');
  msg.className = 'msg';

  const dueOk    = validateDue();
  const amountOk = validateAmount();
  const modeOk   = validateMode();
  const refOk    = validateRef();

  if(!dueOk || !amountOk || !modeOk || !refOk){
    msg.textContent = 'Please fix the highlighted fields before submitting.';
    msg.classList.add('show', 'err');
    const firstInvalid = [
      [dueOk, els.due], [amountOk, els.amount], [modeOk, els.mode], [refOk, els.ref]
    ].find(([ok]) => !ok);
    if(firstInvalid) firstInvalid[1].focus();

    // Log the rejected attempt for the audit trail (US-LRM-05)
    const instN = parseInt(els.due.value, 10) || 0;
    const amount = parseFloat(els.amount.value) || 0;
    logRejected(instN, amount, els.mode.value || '—', 'Failed field validation');
    return;
  }

  // All fields valid — accept the payment
  const instN = parseInt(els.due.value, 10);
  const row = schedule.find(r => r.n === instN);
  paymentsMade = instN;
  history.push({
    ref: 'PAY' + String(refCounter++).padStart(6,'0'),
    date: fmtDate(today()),
    installment: instN,
    amount: row.emi,
    mode: els.mode.value,
    status: 'Success'
  });
  msg.textContent = `Payment for installment #${instN} recorded successfully.`;
  msg.classList.add('show', 'ok');

  // Reset form state for the next entry
  els.ref.value = '';
  [els.due, els.amount, els.mode, els.ref].forEach(el => el.classList.remove('valid', 'invalid'));
  toggleRefField();
  renderAll();
});

function logRejected(instN, amount, mode, reason){
  history.push({
    ref: 'PAY' + String(refCounter++).padStart(6,'0'),
    date: fmtDate(today()),
    installment: instN,
    amount: amount,
    mode,
    status: 'Success'   // placeholder, overwritten below
  });
  history[history.length-1].status = 'Rejected';
  renderHistory();
}

/* ---------- US-LRM-04: simulate time passing to demonstrate auto-overdue ---------- */
document.getElementById('advanceBtn').addEventListener('click', function(){
  simMonthsElapsed += 1;
  renderAll();
});

/* ---------- US-LRM-05: officer-authorized reversal only, history itself immutable ---------- */
document.getElementById('officerToggle').addEventListener('change', renderHistory);

function reversePayment(ref){
  const entry = history.find(h=>h.ref === ref);
  if(!entry) return;
  if(!confirm(`Reverse payment ${ref} for installment #${entry.installment}? This requires officer authorization and will be logged.`)) return;
  entry.status = 'Rejected';
  if(entry.installment === paymentsMade){
    paymentsMade -= 1;
  }
  renderAll();
}

renderAll();