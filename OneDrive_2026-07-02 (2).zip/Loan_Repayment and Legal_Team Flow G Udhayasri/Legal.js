document.addEventListener('DOMContentLoaded', function () {

  /* ============================================================
     SAMPLE CASE DATA
     Replace this with data fetched from your backend/API.
     ============================================================ */
  const documentTypes = [
    'Sale Deed / Title Deed',
    'Encumbrance Certificate',
    'Property Tax Receipts',
    'Approved Building Plan',
    'Occupancy Certificate',
    'NOC from Society / Builder',
    'Previous Chain of Title Documents',
    'Identity &amp; Address Proof'
  ];

  const cases = [
    {
      id: 'HL1234567890', applicant: 'John Doe', loanType: 'Home Loan',
      property: 'Green Park, Bangalore', submitted: '28 Jun 2026',
      priority: 'High', status: 'Pending', amount: '₹ 42,50,000',
      propertyType: 'Residential', propertyValue: '₹ 50,00,000',
      docs: {}
    },
    {
      id: 'HL1234567891', applicant: 'Priya Nair', loanType: 'Plot Loan',
      property: 'Whitefield, Bangalore', submitted: '27 Jun 2026',
      priority: 'Medium', status: 'In Review', amount: '₹ 28,00,000',
      propertyType: 'Plot / Land', propertyValue: '₹ 32,00,000',
      docs: {}
    },
    {
      id: 'HL1234567892', applicant: 'Arjun Mehta', loanType: 'Balance Transfer',
      property: 'Andheri West, Mumbai', submitted: '25 Jun 2026',
      priority: 'Normal', status: 'Clear', amount: '₹ 65,00,000',
      propertyType: 'Apartment', propertyValue: '₹ 78,00,000',
      docs: {}
    },
    {
      id: 'HL1234567893', applicant: 'Sunita Rao', loanType: 'Home Improvement',
      property: 'Salt Lake, Kolkata', submitted: '24 Jun 2026',
      priority: 'High', status: 'Discrepancy', amount: '₹ 15,00,000',
      propertyType: 'Independent House', propertyValue: '₹ 60,00,000',
      docs: {}
    },
    {
      id: 'HL1234567894', applicant: 'Karthik Iyer', loanType: 'Home Loan',
      property: 'Anna Nagar, Chennai', submitted: '22 Jun 2026',
      priority: 'Normal', status: 'Pending', amount: '₹ 38,00,000',
      propertyType: 'Apartment', propertyValue: '₹ 45,00,000',
      docs: {}
    },
    {
      id: 'HL1234567895', applicant: 'Neha Kapoor', loanType: 'NRI Home Loan',
      property: 'Baner, Pune', submitted: '20 Jun 2026',
      priority: 'Medium', status: 'In Review', amount: '₹ 55,00,000',
      propertyType: 'Apartment', propertyValue: '₹ 62,00,000',
      docs: {}
    }
  ];

  let activeCaseId = null;
  let currentFilter = 'all';

  /* ============================================================
     SIDEBAR PAGE NAVIGATION
     ============================================================ */
  const navItems = document.querySelectorAll('.nav-item');
  const pages = document.querySelectorAll('.page');
  const sidebar = document.getElementById('sidebar');
  const menuToggle = document.getElementById('menuToggle');

  function goToPage(target) {
    navItems.forEach(i => i.classList.toggle('active', i.dataset.page === target));
    pages.forEach(p => p.classList.toggle('active', p.dataset.page === target));
    sidebar.classList.remove('open');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  navItems.forEach(item => {
    item.addEventListener('click', function () {
      goToPage(this.dataset.page);
    });
  });

  document.querySelectorAll('[data-goto]').forEach(btn => {
    btn.addEventListener('click', function () {
      goToPage(this.dataset.goto);
    });
  });

  if (menuToggle) {
    menuToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
  }

  /* ============================================================
     STATUS HELPERS
     ============================================================ */
  function statusClass(status) {
    return status.replace(/\s+/g, '-');
  }

  function updateStats() {
    document.getElementById('statPending').textContent = cases.filter(c => c.status === 'Pending').length;
    document.getElementById('statCleared').textContent = cases.filter(c => c.status === 'Clear').length;
    document.getElementById('statDiscrepancy').textContent = cases.filter(c => c.status === 'Discrepancy').length;
    document.getElementById('statTotal').textContent = cases.length;
    document.getElementById('queueBadge').textContent = cases.filter(c => c.status === 'Pending' || c.status === 'In Review').length;
  }

  /* ============================================================
     RENDER: DASHBOARD TABLE (top 4 open cases)
     ============================================================ */
  function renderDashboardTable() {
    const tbody = document.querySelector('#dashCaseTable tbody');
    tbody.innerHTML = '';

    const openCases = cases.filter(c => c.status === 'Pending' || c.status === 'In Review' || c.status === 'Discrepancy').slice(0, 4);

    openCases.forEach(c => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${c.id}</td>
        <td class="applicant-cell">${c.applicant}<span class="sub">${c.loanType}</span></td>
        <td>${c.property}</td>
        <td>${c.submitted}</td>
        <td><span class="status-badge ${statusClass(c.status)}">${c.status}</span></td>
        <td><button class="review-btn" data-case="${c.id}">Review</button></td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.review-btn').forEach(btn => {
      btn.addEventListener('click', () => openCase(btn.dataset.case));
    });
  }

  /* ============================================================
     RENDER: RECENT ACTIVITY
     ============================================================ */
  function renderActivity() {
    const activity = [
      { text: 'Legal opinion submitted for <b>HL1234567892</b> — Title Clear', time: 'Today, 11:40 AM' },
      { text: 'Discrepancy flagged on <b>HL1234567893</b> — missing Occupancy Certificate', time: 'Today, 9:15 AM' },
      { text: 'New case <b>HL1234567895</b> assigned for review', time: 'Yesterday, 5:20 PM' },
      { text: 'Encumbrance search completed for <b>HL1234567891</b>', time: 'Yesterday, 2:05 PM' }
    ];

    const list = document.getElementById('activityList');
    list.innerHTML = '';
    activity.forEach(a => {
      const li = document.createElement('li');
      li.innerHTML = `<span class="activity-dot"></span><div>${a.text}<span class="activity-time">${a.time}</span></div>`;
      list.appendChild(li);
    });
  }

  /* ============================================================
     RENDER: CASE QUEUE TABLE
     ============================================================ */
  function renderQueue() {
    const tbody = document.querySelector('#queueTable tbody');
    tbody.innerHTML = '';

    const filtered = currentFilter === 'all' ? cases : cases.filter(c => c.status === currentFilter);

    filtered.forEach(c => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${c.id}</td>
        <td class="applicant-cell">${c.applicant}<span class="sub">${c.propertyType}</span></td>
        <td>${c.loanType}</td>
        <td>${c.property}</td>
        <td>${c.submitted}</td>
        <td><span class="priority-tag ${c.priority}">${c.priority}</span></td>
        <td><span class="status-badge ${statusClass(c.status)}">${c.status}</span></td>
        <td><button class="review-btn" data-case="${c.id}">Review</button></td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.review-btn').forEach(btn => {
      btn.addEventListener('click', () => openCase(btn.dataset.case));
    });
  }

  document.querySelectorAll('.filter-chip').forEach(chip => {
    chip.addEventListener('click', function () {
      document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
      this.classList.add('active');
      currentFilter = this.dataset.filter;
      renderQueue();
    });
  });

function openCase(caseId) {
    const c = cases.find(x => x.id === caseId);
    if (!c) return;
    activeCaseId = caseId;

    document.getElementById('caseTitle').textContent = `Loan A/C — ${c.id}`;
    document.getElementById('caseSubtitle').textContent = `${c.applicant} · ${c.loanType} · Submitted ${c.submitted}`;

    const badge = document.getElementById('caseStatusBadge');
    badge.textContent = c.status;
    badge.className = `status-badge ${statusClass(c.status)}`;

    document.getElementById('caseSummaryGrid').innerHTML = `
      <div class="review-item"><span class="review-label">Applicant Name</span>${c.applicant}</div>
      <div class="review-item"><span class="review-label">Loan Amount</span>${c.amount}</div>
      <div class="review-item"><span class="review-label">Loan Type</span>${c.loanType}</div>
      <div class="review-item"><span class="review-label">Property Type</span>${c.propertyType}</div>
      <div class="review-item"><span class="review-label">Property Location</span>${c.property}</div>
      <div class="review-item"><span class="review-label">Declared Property Value</span>${c.propertyValue}</div>
    `;

    // Document checklist
    const checklist = document.getElementById('docChecklist');
    checklist.innerHTML = '';
    documentTypes.forEach((doc, i) => {
      const row = document.createElement('div');
      row.className = 'doc-row';
      row.innerHTML = `
        <span class="doc-name">${doc}</span>
        <select data-doc="${i}">
          <option value="pending" ${c.docs[i] === 'pending' || !c.docs[i] ? 'selected' : ''}>Pending Review</option>
          <option value="verified" ${c.docs[i] === 'verified' ? 'selected' : ''}>Verified</option>
          <option value="discrepancy" ${c.docs[i] === 'discrepancy' ? 'selected' : ''}>Discrepancy Found</option>
          <option value="not-submitted" ${c.docs[i] === 'not-submitted' ? 'selected' : ''}>Not Submitted</option>
        </select>
      `;
      checklist.appendChild(row);
    });

    checklist.querySelectorAll('select').forEach(sel => {
      sel.addEventListener('change', function () {
        c.docs[this.dataset.doc] = this.value;
      });
    });

    // Uploaded documents (sample list)
    document.getElementById('caseDocFiles').innerHTML = `
      <li>Sale_Agreement.pdf <a href="#">View</a></li>
      <li>Encumbrance_Certificate.pdf <a href="#">View</a></li>
      <li>Property_Tax_Receipt.pdf <a href="#">View</a></li>
      <li>Approved_Building_Plan.pdf <a href="#">View</a></li>
      <li>Applicant_ID_Proof.pdf <a href="#">View</a></li>
    `;

    // Timeline (sample)
    document.getElementById('caseTimeline').innerHTML = `
      <li>Case assigned to Legal Team<span class="t-date">${c.submitted}</span></li>
      <li>Document verification in progress<span class="t-date">${c.submitted}</span></li>
      <li>Awaiting legal opinion<span class="t-date">Today</span></li>
    `;

    goToPage('case-detail');
  }

  document.getElementById('backToQueue').addEventListener('click', () => goToPage('case-queue'));

  /* ============================================================
     SAVE / SUBMIT ACTIONS
     ============================================================ */
  function getLegalOpinionValue() {
    const checked = document.querySelector('input[name="legalOpinion"]:checked');
    return checked ? checked.value : null;
  }

  document.getElementById('saveDraftBtn').addEventListener('click', function () {
    alert('Draft saved. You can return to this case anytime from the Case Queue.');
  });

  document.getElementById('submitOpinionBtn').addEventListener('click', function () {
    const opinion = getLegalOpinionValue();
    if (!opinion) {
      alert('Please select an overall legal opinion before submitting.');
      return;
    }

    const c = cases.find(x => x.id === activeCaseId);
    if (!c) return;

    if (opinion === 'clear') c.status = 'Clear';
    else if (opinion === 'not-clear') c.status = 'Discrepancy';
    else c.status = 'In Review';

    alert(`Legal opinion submitted for ${c.id}. Status updated to "${c.status}".`);

    updateStats();
    renderDashboardTable();
    renderQueue();
    goToPage('case-queue');
  });

  /* ============================================================
     SEARCH
     ============================================================ */
  document.getElementById('caseSearch').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      const term = this.value.trim().toLowerCase();
      if (!term) return;
      const match = cases.find(c => c.id.toLowerCase().includes(term) || c.applicant.toLowerCase().includes(term));
      if (match) {
        openCase(match.id);
      } else {
        alert('No matching case found.');
      }
    }
  });

  /* ============================================================
     INIT
     ============================================================ */
  updateStats();
  renderDashboardTable();
  renderActivity();
  renderQueue();
});